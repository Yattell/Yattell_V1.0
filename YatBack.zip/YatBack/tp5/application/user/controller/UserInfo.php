<?php

namespace app\user\controller;

use app\user\model\User as UserModel;
use think\Request;

class UserInfo
{
  public function register()
  {
    $data = input('post.');
    $user = new UserModel;
    if(UserInfo::user_not_exist($data['email']))
    {
      $check = array(UserInfo::user_basic_info($user,$data),
                     UserInfo::user_profile($user,$data),
                     UserInfo::user_security($user,$data)
                   );
      foreach($check as $result){
        if($result != True){
          return $result;
        }
      }
      return UserModel::get(['email' => $data['email']]);
    }
    return 'The user already exists!';
  }

  public function login()
  {
    $data = input('post.');
    $user = UserModel::get(['email' => $data['email']]);
    if($user!=NULL && $user[password] == md5($data['password'])){
      //put in menory
      return true;
    }
    return false;
  }
  private function user_not_exist($email)
  {
    $not_exist = True;
    if(UserModel::get(['email' => $email]))
    {
      $not_exist = False;
    }
    return $not_exist;
  }
  // +----------------------------------------------------------------------
  // | Users info
  // +----------------------------------------------------------------------
  private function user_basic_info($user,$data)
  {
    $basicinfo = array('nickname', 'email', 'password');
    foreach($basicinfo as $key){
      if($key == 'password')
      {
        $user[$key] = md5($data[$key]);
      }else
      {
        $user[$key] = $data[$key];
      }
    }
    try{
      $user->save();
      return True;
    }catch(Exception $e){
      return $e->getMessage();
    }
  }

  private function user_profile($user,$data)
  {
    $profileinfo = array('first_name','last_name','middle_name', 'sex', 'company','job_title','address','birthday','contact_number');
    foreach($profileinfo as $key){
      if($key == 'birthday')
      {
        $profile[$key] = date($data[$key]);
      }
      else
      {
        $profile[$key] = $data[$key];
      }

    }
    try{
      $user->profile()->save($profile);
      return True;
    }catch(Exception $e){
      return $e->getMessage();
    }
  }

  private function user_security($user,$data)
  {
    $secureinfo = array("security_question", "security_answer");
    foreach($secureinfo as $key){
      if($key == 'security_answer'){
        $security[$key] = md5($data[$key]);
      }
      else
      {
        $security[$key] = $data[$key];
      }
    }
    try{
      $user->security()->save($security);
      return True;
    }catch(Exception $e){
      return $e->getMessage();
    }
  }

  public function delete($id)
  {

  }

  public function read($id)
  {
    $user = UserModel::get($id, 'profile');
  }

  public function update($data)
  {

  }
}
