<?php
namespace app\user\controller;

use think\Controller;

class User extends Controller
{
    public function create()
    {
        return view();
    }
}
