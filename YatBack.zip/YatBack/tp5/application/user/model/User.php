<?php

namespace app\user\model;

use think\Model;

class User extends Model
{
  //set to Users table
  protected $table = 'Users';

  //Turn on auto insert
  protected $insert = ['status' => 1, 'type' => 0];

  public function profile()
  {
    //Every user has only one profile
    return $this -> hasOne('Profile','Users_id');
  }

  public function security()
  {
    return $this->hasOne('Security','Users_id');
  }
}
