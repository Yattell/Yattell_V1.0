<?php

namespace app\user\model;

use think\Model;

class Security extends Model
{
  protected $table = 'SecurityInfo';

  public function user()
  {
    return $this->blongsTo('User');
  }

}
