<?php

namespace app\user\model;

use think\Model;

class Profile extends Model
{
  protected $table = 'Profiles';
  protected $autoWriteTimestamp = true;
  /*protected $type = [
    'birthday' => 'timestamp:Y-m-d',
  ];
  */

  public function user()
  {
    return $this -> blongsTo('User');
  }
}
