<?php

namespace app\user\validation;

use think\Validate;

class User extends Validate
{
  protected $rule = [
    'first_name' => ['require','max:45'],
    'last_name' => ['require','max:45'],
    'sex' => ['require'],
    'email' => ['require', 'email'],
    'birthday' => ['dateFormat' => 'Y-m-d'],
  ];
}
