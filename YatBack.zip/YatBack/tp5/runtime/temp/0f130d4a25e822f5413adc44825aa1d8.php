<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:106:"/Library/WebServer/Documents/YatBack/tp5/public/../application/users/view/index/yattell_register_user.html";i:1497626961;}*/ ?>
<!DOCTYPE HTML>

<html>
	<head>
		<title>User Registration</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" type="text/css" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body class="landing">

		<!-- Header -->
			<header id="header">
				<div class="container">
					<h1><a href="index.html" class="icon fa-qq">Yattell</a></h1>
					<nav id="nav">
						<ul>
              <li><a href="index.html">Home</a></li>
              <li><a href="yattell_ai.html">AI</a></li>
              <li><a href="yattell_business.html">Business</a></li>
              <li><a href="yattell_finance.html">Finance</a></li>
              <li><a href="yattell_article.html">Article</a></li>
              <li><a href="yattell_upload.html">Upload</a></li>
              <li class="current"><a href="yattell_login.html">Login</a></li>
							<li><a href="yattell_search.html" class="icon fa-search"></a></li>
						</ul>
					</nav>
				</div>
			</header>

		<!-- Page Wrapper -->
			<div id="page-wrapper">

        <section class="wrapper style2">
          <div class="container">
            <h3> User Registration </h3>
            <hr>
            <div class="row uniform 200%">

              <!-- Left Buffer -->
              <div class="2u 0u$(medium)">
              </div>

              <!-- Registration Form -->
              <div class="8u 12u$(medium)">
                <form method="post" action="#">
                  <h3> Username *</h3>
                  <input type="text" name="username" id="username" value="" placeholder="Username"/>
                  <h3> Email *</h3>
                  <input type="text" name="email" id="email" value="" placeholder="Email"/>
                  <h3> Password *</h3>
                  <input type="text" name="password" id="password" value="" placeholder="Password"/>
                  <h3> Retype Password *</h3>
                  <input type="text" name="re_password" id="re_password" value="" placeholder="Retype Password"/>
                  <h3> First Name *</h3>
                  <input type="text" name="first_name" id="first_name" value="" placeholder="First Name"/>
                  <h3> Last Name *</h3>
                  <input type="text" name="last_name" id="last_name" value="" placeholder="Last Name"/>

                  <hr>

                  <ul class="actions align-center">
                    <li><input type="reset" value="Reset Form" /></li>
                    <li><input type="submit" value="Register" class="special" /></li>
                  </ul>
                </form>
              </div>

              <!-- Right Buffer -->
              <div class="2u 0u$(medium)">
              </div>
            </div>


          </div>
        </section>
				<!-- Footer -->
					<footer id="footer">
						<ul class="major-icons">
							<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
							<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
							<li><a href="yattell_contact.html" class="icon fa-envelope"><span class="label">Email</span></a></li>
						</ul>
            <p class="copyright">&copy; Yattell Technology Inc. All rights reserved.</p>
					</footer>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
      <script src="assets/js/jquery.slidertron.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>
