<?php

namespace app\index\model;

use app\index\model\CacheModel;

class SecurityInfo extends CacheModel
{
  private $keys = array("security_question", "security_answer");
  private $replace = [];

  public function users()
  {
    return $this->blongsTo('User');
  }
  public function test()
  {
    return 'hello world';
  }

  public function add($user, $data)
  {
    $reply = CacheModel::begin($this->keys, $data, $this->replace);
  }
}
