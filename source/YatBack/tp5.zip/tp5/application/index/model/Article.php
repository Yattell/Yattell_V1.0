<?php

namespace app\index\model;

use app\index\model\CacheModel;
use app\index\model\TagRelation;
use app\common\traits\Resource;

class Article extends CacheModel
{
  use Resource;
  //Turn on auto insert
  protected $insert = ['status' => 1];

  private $keys = array('title', 'punchline','summary', 'content', 'thumbnail');
  private $replace = [];

  public function tags()
  {
    return $this->belongsToMany('Tag','TagRelation');
  }

  public function comments()
  {
    return $this->morphMany('Comment', 'commentable');
  }

  public function users()
  {
    return $this->blongsTo('User');
  }
  public function add($user, $data)
  {
    $result = $this->uploadFile($data['content']);
    $data['content'] = $result;
    $article = CacheModel::begin($this->keys, $data);
    $article['user_id'] = $user['id'];
    $article['views'] = 0;
    if($user->articles()->save($article)){
      return Article::get(['title'=>$data['title']]);
    }
    exception('Unknown Problem!', 404);
  }

  public function getArticle($id)
  {
    $article = Article::get($id);

    if($article){
      $article['views'] += 1;
      $article->save();
      $article['content'] = $this->getFile($article['content']);
      return $article;
    }
    else{
      throw new Exception('Article id'.$id.'does not exist');
    }
  }

  public function getArticles()
  {
    return Article::all();
  }

  public function getArtList($want, $require)
  {
    return Article::get([$want => $require]);
  }
}
