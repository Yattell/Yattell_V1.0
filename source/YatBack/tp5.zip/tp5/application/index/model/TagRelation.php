<?php
namespace app\index\model;

use app\index\model\CacheModel;

class TagRelation extends CacheModel
{
  protected $table = 'user_article_tag';
  protected $insert = ['status' => 1];

  public function add($user_id, $article_id, $tags_id)
  {
    foreach($tags_id as $id)
    {
        $new = new TagRelation;
        $new['user_id']=$user_id;
        $new['article_id']=$article_id;
        $new['tag_id']=$id;
        $new->save();
    }
    return 'success';
  }
}
