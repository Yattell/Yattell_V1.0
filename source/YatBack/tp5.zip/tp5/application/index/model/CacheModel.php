<?php

namespace app\index\model;

use app\index\model\MySQLModel;
use think\cache;
use think\Request;
use app\index\model\Article;

class CacheModel extends MySQLModel
{
  public function memoryinsert($time, $cc=true, $thing)
  {
    if($cc==true){

    }
  }

  public function memoryget($key, $bc=true)
  {
    if($bc==true)
    {
      $data = Cache::get($key);
      if($data){
        return ['data' => $data, 'memory' => true];
      }else{
        $thing = MySQLModel::retrive($key);
        $pwd = bin2hex(openssl_random_pseudo_bytes(4));
      }
    }
  }

  public function memoryupdate($key, $bc=true)
  {

  }
}
