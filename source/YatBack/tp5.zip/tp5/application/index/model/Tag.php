<?php

namespace app\index\model;

use app\index\model\CacheModel;

class Tag extends CacheModel
{

  public $keys;

  protected $insert = ['status' => 1];

  public function articles()
  {
    return $this->blongsToMany('Article', 'tagArticle');
  }

  public function users()
  {
    return $this->blongsToMany('User', 'tagUser');
  }

  public function add($name)
  {
    $tag = Tag::get(['name'=>$name]);
    if($tag)
    {
      return $tag['id'];
    }
    $tag = new Tag;
    $tag['name'] = $name;
    if($tag->save())
    {
      return $tag['id'];
    }else
    {
      exception('Unknown problem!', 404);
    }
  }

  public function addAll($names)
  {
    $tags = [];
    foreach($names as $name){
      $id = $this->add($name);
      if(in_array($id,$tags)==false){
        $tags[]=$id;
      }
    }
    return $tags;
  }
}
