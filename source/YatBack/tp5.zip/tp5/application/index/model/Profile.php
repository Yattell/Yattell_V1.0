<?php

namespace app\index\model;

use app\index\model\CacheModel;

class Profile extends CacheModel
{

  private $keys = array('first_name','last_name','middle_name', 'sex', 'company','job_title','address','birthday','contact_number','startup','executive');
  private $replace = [];

  public function users()
  {
    return $this -> blongsTo('User');
  }

  public function add($user, $data)
  {

  }
}
