<?php

namespace app\index\model;

use app\index\model\CacheModel;
use app\common\traits\Cached;

class User extends CacheModel
{
  use Cached;
  //Turn on auto insert
  protected $insert = ['status' => 1, 'user_type' => 'basic'];

  public function profile()
  {
    //Every user has only one profile
    return $this -> hasOne('Profile');
  }

  public function security()
  {
    return $this->hasOne('SecurityInfo');
  }

  public function comments()
  {
    return $this->hasMany('Comment');
  }

  public function replies()
  {
    return $this->hasMany('Reply');
  }

  public function tags()
  {
    return $this->belongsToMany('Tag');
  }

  public function articles()
  {
    return $this->hasMany('Article');
  }

  public function add($data)
  {
    $user = new User;
    $basicinfo = array('nickname', 'email', 'password');
    $profileinfo = array('first_name','last_name','middle_name', 'sex', 'company','job_title','address','birthday','contact_number','startup','executive');
    $secureinfo = array("security_question", "security_answer");
    foreach($basicinfo as $key){
      if($key == 'password')
      {
        $user[$key] = md5($data[$key]);
      }else
      {
        $user[$key] = $data[$key];
      }
    }
    if($user->save()){
      foreach($profileinfo as $key){
        if(array_key_exists($key, $data)){
          $profile[$key] = $data[$key];
        }
      }
      if($user->profile()->save($profile)){
        foreach($secureinfo as $key){
          if($key == 'security_answer'){
            $security[$key] = md5($data[$key]);
          }
          else
          {
            $security[$key] = $data[$key];
          }
        }
        $user->security()->save($security);
        return 'Ok!';
      }
      else{
        exception('Unknown Problem!', 404);
      }
    }
    else{
      exception('Unknown Problem!', 404);
    }

  }
  public function users($email,$password)
  {
    $user = User::get(['email' => $email]);
    return $user;
  }

  public function readUser()
  {
    $data = input('post.');
    $user_info = Cache::get($data['key']);
    if($user_info){
      return $user_info;
    }else{
      return false;
    }
  }
}
