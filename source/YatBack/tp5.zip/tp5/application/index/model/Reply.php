<?php
namespace app\index\model;

use app\index\model\CacheModel;
use app\common\traits\Resource;

class Reply extends CacheModel
{
  Use Resource;
  //Turn on auto insert
  protected $insert = ['status' => 1];

  private $keys = ['memory', 'content', 'reply_type', 'reply_id','touser_id','comment_id','user_id'];
  private $replace = ['reply_type'=>'type'];

  public function comments()
  {
    return $this->morphMany('Comment', 'commentable');
  }

  public function commentable()
  {
    return $this->morphTo();
  }

  public function add($user, $data)
  {
    $reply = new Reply;
    $data['user_id'] = $user['id'];
    $reply = CacheModel::initBegin($reply, $this->keys, $data, $this->replace);
    if($reply->save())
    {
      return $reply;
    }
    exception('Unknown Problem');
  }
}
