<?php
namespace app\index\model;

use app\index\model\CacheModel;
use app\common\traits\Resource;
use app\common\traits\Key;

class Comment extends CacheModel
{
  Use Resource;
  //Turn on auto insert
  protected $insert = ['status' => 1];

  private $keys = ['memory', 'content', 'commentable_type', 'commentable_id','user_id'];
  private $replace = ['commentable_type'=>'type', 'commentable_id'=>'com_id'];

  public function commentable()
  {
    return $this->morphTo();
  }

  public function add($user, $data)
  {
    $data['user_id'] = $user['id'];
    $comment = new Comment;
    $comment = CacheModel::initBegin($comment,$this->keys, $data, $this->replace);
    if($comment->save())
    {
      return $comment;
    }
    exception('Unknown Problem');
  }
}
