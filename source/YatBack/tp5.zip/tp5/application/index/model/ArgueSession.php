<?php
namespace app\index\model;

use app\index\model\CacheModel;

class ArgueSession extends CacheModel
{
  protected $insert = ['status'=>1];

  public function comments()
  {
    return $this->morphMany('Comment', 'commentable');
  }
}
