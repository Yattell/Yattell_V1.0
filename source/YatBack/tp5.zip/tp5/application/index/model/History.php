<?php
namespace app\index\model;

use app\index\model\CacheModel;

class History extends CacheModel
{
  protected $table = "View_History";

  protected $insert =['status'=>1];

  public function add(){
    
  }
}
