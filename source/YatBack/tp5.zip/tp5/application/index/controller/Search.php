<?php

namespace app\index\controller;

use app\index\controller\MyController;
use think\Db;

class Search extends MyController
{
  public function searchbytitle($title)
  {
    $article = model('Article');
    $result = $article->getArtList('title', $title);
    Db::table('Articles')->

  }
}
