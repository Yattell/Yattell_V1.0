<?php

namespace app\index\controller;

use app\index\controller\MyController;
use think\Db;

class Tag extends MyController
{
  public function uploadtag()
  {
    $data = input('post.');
    $result  = Db::table('Tags')->
              where([
                'name'=>$data['name'],
                'users_id'=>$data['users_id'],
                'articles_id'=> $data['articles_id'],
                ])->
              find();
    if($result){
      return 'You already submit this tag';
    }
    return MyController::upload('Tag');
  }
}
