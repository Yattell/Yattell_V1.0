<?php

namespace app\index\controller;

use app\index\controller\MyController;
use app\index\model\User as UserModel;
use app\index\model\Article as ArticleModel;
use app\index\model\Comment as CommentModel;
use app\index\model\Reply as ReplyModel;
use think\Db;
use think\Cache;
//use think\Exception;

class User extends MyController
{
  public function register()
  {
    $data = input('post.');
    $result  = UserModel::get(['email' => $data['email']]);
    if($result)
    {
      $this->myerror(404, 'User already exists!');
    }
    return model('User')->add($data);
  }

  public function login()
  {
    $email = input('post.email');
    $password = input('post.password');
    $user = UserModel::get(['email' => $email, 'password' => md5($password)]);
    if($user){
      $result = $user->cacheOption('expire',3600)->cachedUsers($email,$password);
      $args = array($email,$password, get_class($user), "Users");
      $key = md5(serialize($args));
      return ['cache_key'=>$key];
    }
    $this->myerror(404, 'Email and password do not match');
  }

  public function logout()
  {
    $key = input('post.key');
    Cache::rm($key);
    return 'Success!';
  }

  public function profile($key)
  {
    $user = Cache::get($key);
    if($user)
    {
      $result = $user->profile;
      $result['nickname'] = $user->nickname;
      return $result;
    }
    $this->myerror(404, 'Please login again!');
  }

  public function history($user)
  {
    $result = Db::table('View_History')->
              where(['users_id'=>$user, 'status'=>1])->
              select();
    return json_encode($result);
  }

  public function uploadarticle()
  {
    $data = input('post.');
    $result  = ArticleModel::get(['title'=>$data['title']]);
    //$user = Cache::get($data['cache_key']);
    $user = UserModel::get(1);
    if($user==false)
    {
      $this->myerror(404,'Please login first!');
      return;
    }
    if($result){
      $this->myerror(404,'Article does exist');
      return;
    }
    else
    {
      $tags_id = model('Tag')->addAll($data['looseTags']);
      $strong = model('Tag')->addAll($data['specificTags']);
      $article = model('Article')->add($user, $data);
      $user_id = $user['id'];
      $article_id = $article['id'];
      model('TagRelation')->add($user_id,$article_id,$tags_id);
      for ($i=0; $i<5;$i++)
      {
        model('TagRelation')->add($user_id,$article_id,$strong);
      }
    }
    return 'Success';
  }

  public function commented()
  {
    $data = input('post.');
    //$data = ['key'=>'6c442d5dde1114882fef2f07abed2f13','content'=>'hello world', 'type' => 'Article', 'com_id' => 3];
    if($data['type'] == 'reply' || $data['type'] == 'comment')
    {
      return $this->reply($data);
    }
    else{
      return $this->writecomment($data);
    }
  }

  public function writecomment($data)
  {
    //$user = Cache::get($data['key']);
    $user = UserModel::get(4);
    //dump($user);
    if($user==false){
      $this->myerror(404, 'Please login first!');
      return;
    }
    $comment = new CommentModel;
    $data['memory'] = 0;
    if(strlen($data['content']) > 145)
    {
      $data['content'] = $comment->uploadFile($data['content']);
      $data['memory'] = 1;
    }
    if($data['type'] == "Article")
    {
      $result = $comment->add($user, $data);
      return $result;
    }

  }

  public function reply($data)
  {
    //$user = Cache::get($data['key']);
    $user = UserModel::get(4);
    $data=['content'=>'reply1','reply_id'=>3,'type'=>'comment'];
    if($user){
      $data['memory'] =0;
      $reply = new ReplyModel;
      if(strlen($data['content'])>145)
      {
        $data['content'] = $reply->uploadFile($data['content']);
        $data['memory'] = 1;
      }
      if($data['type'] == "comment")
      {
        $comment = CommentModel::get($data['reply_id']);
      }
      elseif($data['type'] == 'reply')
      {
        $comment = ReplyModel::get($data['reply_id']);
      }
      $data['comment_id'] = $comment['id'];
      $data['touser_id']=$comment['user_id'];
      $result = model('Reply')->add($user, $data);
      return $result;
    }
    $this->myerror(404, 'Please login first!');
  }

  public function deletehistory()
  {

  }
}
