<?php
namespace app\index\controller;

use app\index\controller\MyController;
use app\index\model\User as UserModel;
use think\Cache;

class Lock extends MyController
{
  public function check()
  {
    $key = input('post.key');
    $user = Cache::get($key);
    if($user)
    {
      return $user;
    }
    $this->myerror(404, 'You do not have permission!');
  }

  public function insert($id)
  {
    $user = UserModel::get($id);
    $key = md5(serialize([$id,$user['email'],$user['password']]));
    Cache::set($key, $user);
    return $key;
  }
}
