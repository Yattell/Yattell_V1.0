<?php

namespace app\index\controller;

use think\Controller;
use think\Request;
use think\Db;

class MyController extends Controller
{
  public function upload($model)
  {
    $open = model($model);
    $res = $open->add();
    return $res;
  }

  public function myerror($code, $mes)
  {
    header('HTTP/1.1 '.$code.' '.$mes);
  }
}
