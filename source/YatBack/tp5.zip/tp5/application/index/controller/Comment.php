<?php
namespace app\index\controller;

use app\index\controller\MyController;
use think\Cache;

class Comment extends MyController
{
  public function addcomment()
  {
    $key = input('post.users_id');
    $user = Cache::get($key);
    if($user)
    {
      return MyController::upload('Comment');
    }
    exception('Please login before comment!', 404);
  }
}
