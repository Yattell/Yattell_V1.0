SET @article = ?;
DROP VIEW IF EXISTS Tagviews;
CREATE VIEW Tagviews AS
SELECT article_id as article, tag_id as tag,count(user_id) as tagview
FROM user_article_tag uat
GROUP BY article_id, tag_id;

DROP VIEW IF EXISTS Tagnum ;
CREATE VIEW Tagnum AS
SELECT article_id as article1,count(user_id) as totalview
FROM user_article_tag uat
GROUP BY article_id;


DROP VIEW IF EXISTS Percent;
CREATE VIEW Percent AS
SELECT article, tag, tagview/totalview as percentage
FROM Tagviews, Tagnum
WHERE article1 = article;

DROP VIEW IF EXISTS Score;
CREATE VIEW Score AS
SELECT p1.article as article1, p2.article as article2,p1.percentage*p2.percentage as score
FROM Percent p1, Percent p2
WHERE p1.article<>p2.article and p1.tag = p2.tag;


SELECT id, punchline, score
FROM
(SELECT article1, article2, sum(score) AS score
FROM Score
GROUP BY article1, article2
HAVING article1 = @article
ORDER BY score DESC) Similar, Article
WHERE article2 = id
LIMIT 3;
