<?php

namespace app\index\controller;

use app\index\controller\MyController;
use app\index\model\Article as ArticleModel;
use app\index\model\Tag as TagModel;
use app\index\model\User as UserModel;
use app\index\model\Comment as CommentModel;
use think\Db;

class Article extends MyController
{

  public function read($id)
  {
    $article = ArticleModel::get(['id'=>$id,'status'=>1]);
    if($article)
    {
      $article['views'] +=1;
      $article->save();
      $article['tags'] = Db::query('SELECT name
         FROM tag, article, user_article_tag ust
          WHERE tag.id = ust.tag_id AND ust.article_id = article.id AND article.id = ? AND ust.status=1',[$id]);
      $article['content'] = $article->getFile($article['content']);
      $this->assign('article',json_encode($article));
      $this->assign('comments', json_encode($this->getComments($id)));
      $this->assign('related',json_encode($this->related($id)));
      return $this->fetch('article');
    }
    $this->myerror(404,'Cannot find the article');
  }


  public function readbydate($date)
  {
    $list = Db::query("select * from Article where Date(update_time)=? and status=1", [$date]);
    return $list;
  }

  public function getComments($article)
  {
    $list = Db::query('SELECT comment.id, COUNT(reply.id) AS replies, comment.memory, comment.content, nickname AS auth, profile_pic AS auth_pic
     FROM (comment LEFT JOIN Reply ON comment_id = comment.id), User
      WHERE comment.status = 1 AND comment.user_id = user.id AND comment.commentable_id = ? AND comment.commentable_type = "Article"
      GROUP BY comment.id;',[$article]);
      for($i=0; $i<count($list); $i++)
      {
        if($list[$i]['memory'] == 1)
        {
          $list[$i]['content']=model('Comment')->getFile($list[$i]['content']);
        }
      }
    //dump($list);
    return $list;
  }

  public function getReplis($comment)
  {
    $root = Db::query('SELECT comment.id, user.nickname AS auth, user.profile_pic AS auth_pic, content, memory
                FROM Comment, User
                WHERE comment.user_id = user.id AND comment.id = ? AND comment.status = 1', [$comment]);
    if(empty($root))
    {
      $this->myerror(404,'Comment is no longer exists!');
    }
    else{
      $list = Db::query("SELECT priority AS id, auth,auth_pic, user.nickname AS towho, content, memory
     FROM (SELECT user.profile_pic AS auth_pic, reply_type AS type, user.nickname AS auth, reply.id AS priority, reply.touser_id AS touser, reply.content, memory
            FROM User, Reply
             WHERE comment_id = ? AND user.id = reply.user_id AND reply.status = 1) AS r, User
              WHERE r.touser = user.id;",[$comment]);
      $list[] = $root[0];
      for($i=0; $i<count($list); $i++)
      {
        if($list[$i]['memory'] == 1)
        {
          $list[$i]['content']=model('Comment')->getFile($list[$i]['content']);
        }
      }
      return $list;
    }
  }

  public function related($article)
  {

    if ($file = file_get_contents(__DIR__ . "/algorithm.sql")){
        foreach(explode(";", $file) as $query){
            $query = trim($query);
            if (!empty($query) && $query != ";") {
              if(strpos($query,'?')){
                //echo "pass";
                $result=Db::query($query, [$article]);
              }
              else{
                $result=Db::query($query);
              }

            }
        }

        return $result;
    }
    return false;
  }

  public function getbytag($tag)
  {
    $id = TagModel::get(['name'=>$tag]);
    $list = Db::query("select distinct a.id, a.punchline, a.thumbnail
     from (select t1.article_id as a1, t2.article_id as a2
      from user_article_tag t1, user_article_tag t2 where t1.tag_id = t2.tag_id and t1.article_id<t2.article_id and t1.tag_id = ?) r, article a
       where a1=a.id or a2=a.id;",[$id]);
    return $list;
  }
  public function update()
  {

  }
}
