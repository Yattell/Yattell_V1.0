<?php
namespace app\index\controller;

use app\index\controller\MyController;
use app\index\controller\Article;


class Index extends MyController
{
    public function index()
    {
      $article = new Article;
      $today = date("Y-m-d");
      $list = $article->readbydate($today);
      $this->assign('list', json_encode($list));
      $this->assign('date', json_encode($today));
      return view();
    }

    public function bydate($date)
    {
      $article = new Article;
      $list = $article->readbydate($date);
      $this->assign('list', json_encode($list));
      $this->assign('date', json_encode($date));
      return $this->fetch('index');
    }

    public function uploadarticle()
    {
      return $this->fetch('upload');
    }

    public function lockscreen()
    {
      return view();
    }

    public function tag()
    {
      return view();
    }

    public function register()
    {
      return $this->fetch('register');
    }

    public function login()
    {
      return view();
    }

    public function profile()
    {
      return view();
    }

    public function create()
    {
      return view();
    }

    public function article()
    {
      return view();
    }

    public function test()
    {
      $a = model('Comment');
      return dump($a -> keys());
    }
}
