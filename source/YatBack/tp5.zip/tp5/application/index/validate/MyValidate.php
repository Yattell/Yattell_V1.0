<?php

namespace app\index\validation;

use think\Validate;

class MyValidate extends Validate
{
  //return true if given identifiers values exists in the given model.
  public function checkExist($model, $id)
  {

    $result = Db::table($model)->where(fucntion ($query){
      $i = 1;
      $q = $query;
      while ($i<count($id)){
        $q = $q->where($id[$i-1], $id[$i]);
        $i = $i+2;
      }
    });
    if($result){
      return true;
    }
    else{
      return false;
    }
  }
}
