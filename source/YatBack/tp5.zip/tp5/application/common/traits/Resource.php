<?php
namespace app\common\traits;

trait Resource
{

  public function uploadFile($content)
  {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://174.138.59.72:3000/documents?content=".urlencode($content));
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
  }

  public function getFile($key)
  {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://174.138.59.72:3000/documents?id=".substr($key, 1, -1));
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
  }
}
