<?php
namespace app\common\traits;
use think\Cache;

trait Cached
{

  public function __call($name, $args)
  {
    if(substr($name, 0, 6) === 'cached') {
      $method = substr($name, 6);
      if(method_exists($this, $method))
      {
        $args[] = get_class($this);
        $args[] = $method;
        $id = md5(serialize($args));
        $cached = Cache::get($id);
        if($cached === false)
        {
          $cached = call_user_func_array([$this, $method], $args);
          Cache::set($id, $cached);
        }
        return $cached;
      }
    }
    return parent::__call($name, $args);
  }

  public function cacheOption($name, $arg)
  {
    $options = [];
    $options[$name] = $arg;
    Cache::init($options);
    return $this;
  }
}
