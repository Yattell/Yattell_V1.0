<?php
namespace app\common\traits;

trait Key
{
  public function keys()
  {
    $a = explode("\\", get_class($this));
    $class = end($a);
    switch ($class) {
      case 'Comment':
        # code...
        return ['memory', 'content', 'commentable_type', 'commentable_id'];
        break;

      case 'Article':
        return array('title', 'summary', 'content', 'thumbnail');
        break;

      default:
        return 'No such table';
        break;
    }
  }

  public function replace()
  {
    $a = explode("\\", get_class($this));
    $class = end($a);
    switch ($class) {
      case 'Comment':
        # code...
        return ['commentable_type'=>'type', 'commentable_id'=>'id'];
        break;

      default:
        return 'No such table';
        break;
    }
  }
}
