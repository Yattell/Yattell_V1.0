$(document).ready(function () {

  var	$window = $(window),
  test = {
    tag: "AI",
    articles: [{id:"123", title:"hello", punchline:"Fifth", status:"0", views:"23", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/thankyou.gif"},
    {id:"1234", title:"hello", punchline:"Third", status:"0", views:"99", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/Grandeur10.jpg"},
    {id:"1235", title:"hello", punchline:"Fourth", status:"0", views:"88", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/Grandeur12.jpg"},
    {id:"1236", title:"hello", punchline:"Second", status:"0", views:"1003", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/Grandeur11.jpg"},
    {id:"1237", title:"hello", punchline:"First", status:"0", views:"192323", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/Grandeur8.jpg"},
    {id:"12372", title:"hello", punchline:"Sixth", status:"0", views:"2", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/Grandeur5.jpg"}]
  };

  //Retrieve list
  function retrieveList(type) {
    var formattedDate = formatDate(selected_date);
    /*
    if(type === 'latest')
    {
      console.log("SUCCESS: ", test);
      populate(test);
      $popular.text('Displaying Latest');
      $popular.removeClass('special');
    }
    else if (type === 'popular')
    {
      var sorted_test = test.slice();
      popularSort(sorted_test);
      console.log("SUCCESS: ", sorted_test);
      populate(sorted_test);
      $popular.text('Displaying Popular');
      $popular.addClass('special');
    }
    */

    $.ajax({
      //Route to get articles by date.
      type: "POST",
      url: '/index/article/readbydate/',
      data: {date: formattedDate},
      success: function (info) {
        if(type === 'latest')
        {
          console.log("SUCCESS: ", info);
          populate(info);
          $popular.text('Displaying Latest');
          $popular.removeClass('special');
        }
        else if (type === 'popular')
        {
          popularSort(info);
          console.log("SUCCESS: ", info);
          populate(info);
          $popular.text('Displaying Popular');
          $popular.addClass('special');
        }
      },
      error: function (e) {
        console.log("ERROR : ", e);
      }
    });

  }

  //Populate with list
  function populate(list) {
    console.log(list);
    var $left_col = $('#left_col'),
    $right_col = $('#right_col'),
    $single_col = $('#single_col'),
    $section_sep = $('#sectionSeparator'),
    left_content = '',
    right_content = '',
    single_content = '',
    left = true;

    $.each(list.articles, function(i, item) {
       var stub =
       '<div id="stubWrapper">' +
          '<a class="stub" data-value="' + list.articles[i].id + '">' +
            '<div class="box">' +
              '<p> ' + list.articles[i].punchline + '</p>' +
              '<div class="thumbnailWrapper">' +
                '<img src="' + list.articles[i].thumbnail + '"></img>' +
              '</div>' +
            '</div>' +
          '</a>' +
        '</div>';

       if(left) {
         left_content += stub;
         left = false;
       }
       else {
         right_content += stub;
         left = true;
       }

       single_content += stub;
    });

    $left_col.html(left_content);
    $right_col.html(right_content);
    $single_col.html(single_content);

    //Changing Header
    var header = "<h3> Articles tagged " + list.tag + "</h3>";
    $section_sep.html(header);

  }
  $(document).on("click", "a.stub", function() {
    console.log("clicked stub");
    var yattellAID = $(this).data("value");
    localStorage.yattellAID = yattellAID;
    window.location.href = "/index/index/article";
    //window.location.href="/index/index/article?aid=123"
  });

  //End of funcs
  populate(test);
});
