$(document).ready(function () {
  var $article_expander = $('#articleExpander'),
  $article = $('#articleWrapper')[0],
  $tags_expander = $('#tagExpander'),
  $tags = $('#summaryFooter')[0],
  $replyError = $("#replyError"),
  $replyField = $("#replyField"),
  $commentField = $("#commentField"),
  $commentError = $("#commentError"),
  $submitReply = $("#submitReply"),
  $submitComment = $("#submitComment"),
  tagsExpanded = false,
  articleExpanded = false,
  md = window.markdownit(),
  comment_count = 0;

  var testlist = test;
  var article = myarticle;
  var articleID = article.id;
  var comments = mycomments;
  console.log(testlist);
  console.log(article);
  console.log(comments);

  var articleTest = {
    title: "This is the article header, I hope this works.",
    summary: "Hello.\n\n* This is markdown.\n* It is fun\n* Love it or leave it.",
    article: 'Hello.\n\n* This is markdown.\n* It is fun\n* Love it or leave it.',
    tags: ["AI", "ARTIFICIAL INTELLIGENCE", "STEVO", "FINANCE", "JOSHUA"],
    AID: 10000
  };

  var furtherTest = [
    {id:"123", title:"hello", summary:"First", status:"0", views:"192323", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/Grandeur8.jpg"},
    {id:"123", title:"hello", summary:"Sixth", status:"0", views:"2", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/Grandeur5.jpg"}
  ];

 var commentList = [
   {profilePicture: "./images/crowd.jpg", username: "Cyferous", content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.", replies: 2, CID: 888},
   {profilePicture: "./images/crowd.jpg", username: "Mariah", content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.", replies: 0, CID: 222},
   {profilePicture: "./images/crowd.jpg", username: "Nike", content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.", replies: 0, CID: 333}
 ];

 var repliesList = [
   {authPic: "./images/crowd.jpg", auth: "Cyferous", content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.", id: 666, towho: "Nike"},
   {authPic: "./images/crowd.jpg", auth: "Mariah", content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.", id: 777, towho: "Cyferous"},
   {authPic: "./images/crowd.jpg", auth: "Nike", content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.", id: 888}
 ];

 var commentsEmpty = [];
 //Modal
 var $commentModal = $('#commentModal')[0],
 $commentSpan = $('#commentClose');

 $commentSpan.click(function() {
   $commentModal.style.display = "none";
 });
 $(window).click(function(event) {
   if (event.target == $commentModal) {
       $commentModal.style.display = "none";
   }
 });

 var $replyModal = $('#replyModal')[0],
 $replySpan = $('#replyClose');

 $replySpan.click(function() {
     $replyModal.style.display = "none";
 });
 $(window).click(function(event) {
     if (event.target == $replyModal) {
         $replyModal.style.display = "none";
     }
 });

 function getArticle(aid) {
   console.log("getARticle");
   var data = {id: aid};
   console.log(data);
   $.ajax({
     //Route to get articles by ID
     type: "GET",
     url: "/index/article/read",
     data: data,
     success: function(info) {
       console.log("SUCCESS: ", info);
       console.log("S");
       renderArticle(info);
     },
     error: function(e) {
       console.log("ERROR: ", e);
       console.log("e");
     }
   });
 }

function getComments(aid) {
  console.log('hello world');
  console.log(aid);
  $.ajax({
    //Route to get comments by ID
    type: "GET",
    url: "/index/article/getcomments",
    data: {article:aid},
    success: function(info) {
      console.log("SUCCESS: Comment ", info);
      renderComments(info);
    },
    error: function(e) {
      console.log("ERROR: ", e);
    }
  });
}

function getFurther(aid) {
  $.ajax({
    //Route to get further readings by ID
    type: "POST",
    url: "xxxx",
    data: aid,
    success: function(info) {
      console.log("SUCCESS: ", info);
      renderFurther(info);
    },
    error: function(e) {
      console.log("ERROR: ", e);
    }
  })
}

function getReplies(cid) {
  console.log(cid);
  $.ajax({
    //Route to get replies by commentID
    type:"GET",
    url: "/index/article/getreplis",
    data: {comment: cid},
    success: function(info) {
      console.log("SUCCESS: ", info);
      renderReplies(info);
    },
    error: function(e) {
      console.log("ERROR: ", e);
    }
  })
}

function submitReply() {
  var rootID = $replyField.data("rootValue"),
  id = $replyField.data("value"),
  type = $replyField.data("type"),
  content = $replyField.val(),
  user = localStorage.yattellAuthKey,
  data = {
    reply_id: id,
    type: type,
    content: content,
    key: user
  };
  console.log(data);
  $.ajax ({
    //Route to submit a reply to a comment or another reply.
    type: "POST",
    url: "/index/user/commented",
    data: data,
    success: function (info) {
      console.log("SUCCESS: ", info);
      if(type === "reply") {
        var viewReply = 'View Replies(' + info + ')';
        $('#viewReply_' + rootID).text(viewReply);
        $replyModal.style.display = "none";

        getComments(id);
      }
      else {
        var viewReply = 'View Replies(' + info + ')';
        $('#viewReply_' + id).text(viewReply);
        $replyModal.style.display = "none";
      }
    },
    error: function(e) {
      console.log("ERROR: ", e);
      var error = "<h3> An error has occured in submitting your reply. Please try again later.</h3>";
      $replyError.html(error);
    }
  });
}

function submitComment() {
  var user = localStorage.yattellAuthKey,
  content = $commentField.val(),
  type = "Article",
  data = {
    key: user,
    content: content,
    com_id: articleID,
    type: type
  };
  console.log(data);

  $.ajax({
    //Route to submit a reply to the article.
    type: "POST",
    url: "/index/user/commented",
    data: data,
    success: function(info) {
      console.log("SUCCESS: ", info);
      var commentSuccess = "<h4> Your comment has been succesfully posted! </h4>";

      $commentField.val("");
      $commentError.html(commentSuccess);
    },
    error: function(e) {
      console.log("ERROR: ", e);
      var commentError = "<h4> An error has occured with your request. Please try again later.</h4>";

      $commentField.val("");
      $commentError.html(commentError);

    }
  });
}

function renderArticle(info) {
  var $summaryHeader = $("#summaryHeader"),
  $summaryContent = $("#summaryContent"),
  $summaryFooter = $("#summaryFooter"),
  $articleContent = $("#articleContent"),
  header = "",
  s_content = "",
  footer = "",
  art_content = "";

  //Header
  header += "<h3>" + info.title + "</h3>";
  header +=
    '<div class="iconWrapper hor">' +
      '<i class="fa fa-facebook-official fa"></i>' +
      '<i class="fa fa-twitter fa"></i>' +
      '<i class="fa fa-thumbs-up fa"></i>' +
    '</div>';

  //Summary
  s_content = md.render(info.summary);

  //Footer
  $.each(info.tags, function(i, item) {
    footer +=
      "<div class='tag'>" +
        "<p>" + info.tags[i].name + "</p>" +
      "</div>";
  });

  //Article Content
  art_content = md.render(info.content);

  $summaryHeader.html(header);
  $summaryContent.html(s_content);
  $summaryFooter.html(footer);
  $articleContent.html(art_content);
}

function renderComments(info) {
  var $commentsWrapper = $('#commentsWrapper');
  var comments = "";

  if(info.length === 0) {
    comments += "<h3><i> There are no comments here yet, add one! </i></h3>"
  }
  else {
    $.each(info, function(i, item) {
      var comment = "";
      comment +=
        '<div class="comment">' +
          '<div class="row 0%">' +
            '<div class="2u 3u(xsmall)">' +
              '<div class="commentBanner">' +
                '<div class="profilePicture">' +
                  '<img src="' + info[i].auth_pic + '"></img>' +
                '</div>' +
                '<div class="displayName">' +
                  '<p>' + info[i].auth + '</p>' +
                '</div>' +
              '</div>' +
            '</div>' +
            '<div class="10u$ 9u$(xsmall)">' +
              '<div class="commentContent">' +
                '<div class="iconWrapper hor">' +
                  '<i class="fa fa-trash"></i>' +
                '</div>' +
                '<p>' + info[i].content + '</p>' +
              '</div>' +
            '</div>' +
            '<div class="12u$">' +
              '<div class="commentFooter">' +
                '<div class="row">' +
                  '<div class="3u -1u">' +
                    '<div class="actionGroup">' +
                      '<a class="likeButton" data-value="' + info[i].id + '">' +
                        '<i class="fa fa-thumbs-up fa-2x"></i>' +
                        '<p id="likeReply_' + info[i].id + '">Likes ()</p>' +
                    '</a>' +
                    '</div>' +
                  '</div>' +
                  '<div class="5u">' +
                    '<div class="actionGroup">' +
                      '<a class="replyButton" data-value="' + info[i].id + '">' +
                        '<i class="fa fa-comments fa-2x"></i>' +
                        '<p id="viewReply_' + info[i].id + '">View Replies (' + info[i].replies + ')</p>' +
                    '</a>' +
                    '</div>' +
                  '</div>' +
                  '<div class="3u">' +
                    '<div class="actionGroup">' +
                      '<a class="replyTo" data-type="comment" data-value="' + info[i].id + '">' +
                        '<i class="fa fa-mail-reply fa-2x"></i>' +
                        '<p id="replyTo_' + info[i].id + '">Reply</p>' +
                      '</a>' +
                    '</div>' +
                  '</div>' +
                '</div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>';

      comments += comment;
    });
  }
  $commentsWrapper.html(comments);
}

function renderFurther(list) {
  var $furtherReading = $('#furtherReadings');
  $.each(list, function(i, item) {
    var stub =
    '<div id="stubWrapper">' +
       '<div class="box">' +
       /*
         '<div class="iconWrapper hor">' +
           '<i class="fa fa-trash fa"></i>' +
         '</div>' +
       */
         '<a class="stub" data-value="' + list[i].id + '" href="' + list[i].id + '">' +
           '<p> ' + list[i].punchline + '</p>' +
         '</a>' +
         '<div class="iconWrapper hor">' +
           '<i class="fa fa-facebook-official fa"></i>' +
           '<i class="fa fa-twitter fa"></i>' +
           '<i class="fa fa-thumbs-up fa"></i>' +
         '</div>' +
           '<a class="stub" data-value="' + list[i].id + '">' +
             '<div class="thumbnailWrapper">' +
               '<img src="' + list[i].thumbnail + '"></img>' +
             '</div>' +
           '</a>' +
         '</div>' +
       '</div>';

      $furtherReading.append(stub);
  });
}

function renderReplies(info) {
  var $modalCommentsWrapper = $('#modalCommentsWrapper'),
  $modalRepliesWrapper = $('#modalRepliesWrapper'),
  last = info.length - 1,
  comment = "",
  replies = "";

  $.each(info, function(i, item) {
    if(!(i === last)){
      var reply = "";
      reply +=
        '<div class="reply">' +
          '<div class="row 0%">' +
            '<div class="2u 12u$(small)">' +
              '<div class="replyBanner">' +
                '<div class="profilePicture">' +
                  '<img src="' + info[i].authPic + '"></img>' +
                '</div>' +
                '<div class="displayName">' +
                  '<p>' + info[i].auth + '</p>' +
                '</div>' +
              '</div>' +
            '</div>' +
            '<div class="10u$ 12u$(small)">' +
              '<div class="replyContent alt">' +
                '<h4> Reply to ' + info[i].towho + '</h4>' +
                '<p>' + info[i].content + '</p>' +
              '</div>' +
            '</div>' +
            '<div class="12u$">' +
              '<div class="replyFooter">' +
                '<div class="row">' +
                  '<div class="3u -9u">' +
                    '<div class="actionGroup">' +
                      '<a class="replyTo" data-type="reply" data-value="' + info[i].id + '">' +
                        '<i class="fa fa-mail-reply fa-2x"></i>' +
                        '<p id="replyTo_' + info[i].id + '">Reply</p>' +
                      '</a>' +
                    '</div>' +
                  '</div>' +
                '</div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>';

      replies += reply;
    }
    else {
      comment +=
        '<div class="comment alt">' +
          '<div class="row 0%">' +
            '<div class="2u 12u$(small)">' +
              '<div class="commentBanner">' +
                '<div class="profilePicture">' +
                  '<img src="' + info[i].authPic + '"></img>' +
                '</div>' +
                '<div class="displayName">' +
                  '<p>' + info[i].auth + '</p>' +
                '</div>' +
              '</div>' +
            '</div>' +
            '<div class="10u$ 12u$(small)">' +
              '<div class="commentContent">' +
                '<p>' + info[i].content + '</p>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>';
      }
    });

  $modalCommentsWrapper.html(comment);
  $modalRepliesWrapper.html(replies);
}

  //Expander Arrows
  var upArrow = "<i class='fa fa-angle-double-up fa'></i>",
  downArrow = "<i class='fa fa-angle-double-down fa'></i>";

  //Article Expander
  $article_expander.click( function() {
    if(!articleExpanded) {
      $article.style.maxHeight = "2000px";
      $article_expander.html(upArrow);
      articleExpanded = true;
    }
    else {
      $article.style.maxHeight = "0px";
      $article_expander.html(downArrow);
      articleExpanded = false;
    }
  })

  //Tag Expanders
  $tags_expander.click( function() {
    if(!tagsExpanded) {
      $tags.style.maxHeight = "2000px";
      $tags_expander.html(upArrow);
      tagsExpanded = true;
    }
    else {
      $tags.style.maxHeight = "0px";
      $tags_expander.html(downArrow);
      tagsExpanded = false;
    }
  })

  //Get replies per comment
  $(document).on("click", "a.replyButton" , function() {
    console.log('hello');
    console.log($(this).data("value"));
    //Get comment ID to load replies.
    var CID = $(this).data("value");
    $('#replyField').data("rootValue", $(this).data("value"));

    getReplies(CID);
    $commentModal.style.display = "block";

    renderReplies(repliesList);
  });

  //Reply to comment
  $(document).on("click", "a.replyTo", function() {
    console.log('hello');
    console.log($(this).data("value"));

    //Prepare replyField data values to selected comment.
    $replyField.data("value", $(this).data("value"));
    $replyField.data("type", $(this).data("type"));
    $replyField.val("");
    $replyError.html("");

    $replyModal.style.display = "block";
  });

  //Submit Reply
  $submitReply.click(function() {
    console.log($replyField.data("value"));
    console.log($replyField.data("type"));
    submitReply();
  });

  //Submit Comment
  $submitComment.click(function() {
    submitComment();
  });

  renderArticle(article);
  renderComments(comments);
  renderFurther(testlist);


  //renderArticle(articleTest);
  //renderComments(commentList);
  //renderFurther(furtherTest);

});
