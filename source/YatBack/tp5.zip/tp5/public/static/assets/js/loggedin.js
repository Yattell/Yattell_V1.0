$(document).ready(function () {
  var $login_profile  = $('#login_profile'),
  $navList = $('#navList'),
  authKey = localStorage.yattellAuthKey;

  function validateLoggedIn() {
    $.ajax({
      type: "POST",
      url: "xxxx",
      data: authKey,
      success: function(response) {
        if(response === "success") {
            var tab = "<a href='profile.html'>Profile</a>",
            logout = "<a id='logout' href='#'>Logout </a>";
            $login_profile.html(tab);
            $navList.append(logout);
        }
      },
      error: function(e) {
        var tab = "<a href='profile.html'>Profile</a>";
        logout = "<li><a id='logout' href='#'>Logout </a></li>";
        $login_profile.html(tab);
        $navList.append(logout);
      }
    });
  }

  function logoutFunc() {
    $.ajax({
      type: "POST",
      url: "xxxx",
      data: authKey,
      success: function(response) {
        window.location.href="login.html";
        console.log('loggedOut');
      },
      error: function(e) {
        window.location.href="login.html";
        console.log('loggedOut');
      }
    });
  }

  validateLoggedIn();

  $('#logout').click(function () {
    logoutFunc();
  })
})
