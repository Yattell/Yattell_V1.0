$(document).ready(function () {

    var summary = new SimpleMDE({ element: document.getElementById("summary")}),
    article = new SimpleMDE({ element: document.getElementById("article")}),
    punchline = new SimpleMDE({ element: document.getElementById("punchline")});

    function splitTags(tagString) {
      var split = tagString.split(',');
      $.each(split, function(i, item) {
        split[i] = split[i].trim();
      });
      return split;
    }

    function verifyFields() {
      var loose_tags = splitTags($('#looseTags').val()),
      specific_tags = splitTags($('#specificTags').val()),
      title = $('#title').val(),
      thumbnail = $('#thumbnail').val(),
      punchline_content = punchline.value(),
      summary_content = summary.value(),
      article_content = article.value(),
      fields = [
        loose_tags,
        specific_tags,
        title,
        punchline_content,
        summary_content,
        article_content,
        thumbnail
      ];

      let verified = true;
      $.each(fields, function(i, item) {
        if(item === "") {
          verified = false;
        }
      });

      return verified;
    }

    function uploadImage() {
      event.preventDefault();
      var $form = $('#imageUpload')[0],
      $link_display = $('#linkDisplay'),
      url = "http://174.138.59.72:3000/",
      data = new FormData($form);

      console.log($form[0].value);
      if($form[0].value === '') {
        $link_display.html('<h3> You must select an image to upload first! </h3>');
      }
      else {
        $("#btnSubmitImg").prop("disabled", true);

        $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: url,
            crossdomain: true,
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
            success: function (data) {

                $("#result").text(data);
                console.log("SUCCESS : ", data);
                $("#btnSubmitImg").prop("disabled", false);
                var address = data.split('/');
                $link_display.html('<h3> Your uploaded image link is: </h3>' +
                '<p>' + url + address[1] + '/' + address[2] + '</p>')

            },
            error: function (e) {

                $("#result").text(e.responseText);
                console.log("ERROR : ", e);
                $("#btnSubmitImg").prop("disabled", false);
                $link_display.html('<h3> An error has occured uploading your image to server. Please try again</h3>');

            }
        });
      }
    }

    function uploadArticle() {
      if(verifyFields()){
        $("#btnSubmitArticle").prop("disabled", true);
        $("#errorMessage").html("");
        var loose_tags = splitTags($('#looseTags').val()),
        specific_tags = splitTags($('#specificTags').val()),
        title = $('#title').val(),
        thumbnail = $('#thumbnail').val();

        var data = {
          cache_key: localStorage.yattellAuthKey,
          title: title,
          looseTags: loose_tags,
          specificTags: specific_tags,
          punchline: punchline.value(),
          summary: summary.value(),
          content: article.value(),
          thumbnail: thumbnail
        };

        console.log(data);

        $.ajax({
          type: "POST",
          url: '/index/user/uploadarticle',
          data: data,
          success: function(info) {
              console.log('SUCCESS: ', info);
              window.location.href="uploadarticle";
          },
          error: function(e) {
              console.log('ERROR: ', e);
              $("#errorMessage").html("An error has occured, you might not have permission to upload files.");
          }
        });
      }
      else {
        $("#errorMessage").html("<h3>You are missing required fields.</h3>");
      }
    }

    $("#btnSubmitArticle").click(function (event) {
      uploadArticle();
    });

    $("#btnSubmitImg").click(function (event) {
      uploadImage();
    });

});
