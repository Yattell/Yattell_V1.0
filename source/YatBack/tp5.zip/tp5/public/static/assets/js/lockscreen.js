$(document).ready(function () {
  var $keyInput = $('#accessKey'),
  $submitKey = $('#btnSubmitKey'),
  $errorDisplay = $('#keyError');

  function submitKey() {
    if($keyInput.val() === "") {
      var error = "<h3>You did not submit a valid access key. </h3>";
      $errorDisplay.html(error);
    }
    else {
      var data = $keyInput.val();
      console.log(data);

      $.ajax({
        type: "POST",
        url: "/index/lock/check",
        data: {key:data},
        success: function(response) {
          console.log("SUCCESS: ", response);
          localStorage.yattellAccessKey = response;
          window.location.href="frontpage.html"
        },
        error: function(e) {
          console.log("FAILURE: ", e);
          var error = "<h3>You did not submit a valid access key. </h3>";
          $errorDisplay.html(error);
        }
      });
    }
  }

  $submitKey.click( function () {
    submitKey();
  })
});
