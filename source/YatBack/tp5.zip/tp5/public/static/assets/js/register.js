$(document).ready(function() {

  //Radio
  var radiovalue = "";
  $("input:radio[name=sex]").click(function() {
    radiovalue = $(this).val();
    console.log(radiovalue);
  });

  //Modal
  var modal = $('#errorModal')[0];
  var span = $('#close')[0];

  span.onclick = function() {
      modal.style.display = "none";
  }
  window.onclick = function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
      }
  }
  //Email Verification function
  function isValidEmailAddress(emailAddress) {
      var pattern = new RegExp(/^(("[\w-+\s]+")|([\w-+]+(?:\.[\w-+]+)*)|("[\w-+\s]+")([\w-+]+(?:\.[\w-+]+)*))(@((?:[\w-+]+\.)*\w[\w-+]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][\d]\.|1[\d]{2}\.|[\d]{1,2}\.))((25[0-5]|2[0-4][\d]|1[\d]{2}|[\d]{1,2})\.){2}(25[0-5]|2[0-4][\d]|1[\d]{2}|[\d]{1,2})\]?$)/i);
      return pattern.test(emailAddress);
  };

  //Register
  function register() {
    var username = $('#username').val(),
    email = $('#email').val(),
    password = $('#password').val(),
    re_password = $('#re_password').val(),
    first_name = $('#first_name').val(),
    last_name = $('#last_name').val(),
    security_qu = $('#security_question').val(),
    security_ans = $('#security_answer').val(),
    pp = $('#profile_picture').val(),
    sex = radiovalue,
    company = $('#company').val(),
    job_title = $('#job_title').val(),
    contact_number = $('#contact_number').val(),
    startup = 0,
    executive = 0;

    //Checkboxes
    if($('#startup').is(':checked')) {
      startup = 1;
    }
    if($('#executive').is(':checked')) {
      executive = 1;
    }

    //Data payload
    var data = {
      nickname: username,
      email: email,
      password: password,
      first_name: first_name,
      last_name: last_name,
      security_question: security_qu,
      security_answer: security_ans,
      /* Optional */
      sex: sex,
      profile_pic: pp,
      company: company,
      job_title: job_title,
      contact_number: contact_number,
      /*INTS, 1 or 0*/
      startup: startup,
      executive: executive
    };

    console.log(data);
    //Set modal in case error is returned.
    var modalBody = $('#modalBody');


    $.ajax({
      type: 'POST',
      url: '/index/user/register',
      data: data,
      success: function(id) {
        console.log("SUCCESS: ", id);
        window.location.href="login";
      },
      error: function(e) {
        console.log("ERROR: ", e);
        var error = "<p> An error has occured: " + e.statusText + ".</p>";
        modalBody.html(error);
        modal.style.display = 'block';
      }
    })
  }

  function verify_fields() {
    var username = $('#username'),
    email = $('#email'),
    password = $('#password'),
    re_password = $('#re_password'),
    first_name = $('#first_name'),
    last_name = $('#last_name'),
    security_qu = $('#security_question'),
    security_ans = $('#security_answer'),
    terms = $('#terms');
    fields = [username, email, password, re_password, first_name, last_name, security_ans];
    error = "";
    modalBody = $('#modalBody');

    //Missing fields.
    let verified = true;
    $.each(fields, function(i, item) {
      if(item.val() === "") {
        verified = false;
      }
    });

    if(verified == false)
    {
      error += "<p>You are missing required fields.</p>";
    }

    //Password Match
    if(!(password.val() === re_password.val()))
    {
      verified = false;
      error += "<p>Your passwords do not match.</p>";
    }

    //Email in correct format
    if (email.val() !== "") {  // If something was entered
        if (!isValidEmailAddress(email.val())) {
            verified = false;
            error += "<p>Your email is not in a correct format.</p>";
        }
    }

    //TOS checked
    if(!(terms.is(':checked'))){
      verified = false;
      error += "<p>You must accept our terms of service agreement.</p>";
    }

    modalBody.html(error);
    return verified;
  }

  $('#registerButton').click(function() {
    if(!verify_fields()){
        modal.style.display = 'block';
    }

    else {
      console.log("success");
      register();
    }
  })

});
