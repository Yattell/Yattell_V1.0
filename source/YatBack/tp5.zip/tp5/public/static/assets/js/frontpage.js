$(document).ready(function () {

  var	$window = $(window),
  $footer = $('#footer'),
  $left_arr = $('#left_arr'),
  $right_arr = $('#right_arr'),
  $popular = $('#popular'),
  test = [
    {id:"123", title:"hello", punchline:"Fifth. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.", status:"0", views:"23", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/thankyou.gif"},
    {id:"1234", title:"hello", punchline:"Third", status:"0", views:"99", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/Grandeur10.jpg"},
    {id:"1235", title:"hello", punchline:"Fourth", status:"0", views:"88", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/Grandeur12.jpg"},
    {id:"1236", title:"hello", punchline:"Second", status:"0", views:"1003", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/Grandeur11.jpg"},
    {id:"1237", title:"hello", punchline:"First", status:"0", views:"192323", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/Grandeur8.jpg"},
    {id:"12372", title:"hello", punchline:"Sixth", status:"0", views:"2", area_field:"AI", create_time:"2016-04-03", update_time:"2016-05-05", users_id:"1233", thumbnail:"http://174.138.59.72:3000/undefined/Grandeur5.jpg"}
  ];
  var articles = myarticles;
  var checkdate = recievedDate;
  console.log();
  //Modal
  var modal = $('#datePickerModal')[0],
  span = $('#close')[0];

  span.onclick = function() {
      modal.style.display = "none";
  }
  window.onclick = function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
      }
  }

  //Dates
  var today = new Date(),
  earliest_date = new Date(2017,6,16),
  $cal_trigger = $('#cal_trigger'),
  $picked_date = $('#picked_date'),
  $submit_date = $('#submit_date'),
  $date_error = $('#date_error');

  var separated = checkdate.split("-"),
  selected_date = new Date(separated[0], separated[1], separated[2]);
  console.log(today);
  console.log(selected_date);
  //Reset time
  today.setHours(0,0,0,0);
  selected_date.setHours(0,0,0,0);
  earliest_date.setHours(0,0,0,0);

  function formatDate(date) {
    var dd = date.getDate();
    var mm = date.getMonth()+1; //January is 0!

    var yyyy = date.getFullYear();
    if(dd<10){
        dd='0'+dd;
    }
    if(mm<10){
        mm='0'+mm;
    }
    var formattedDate = yyyy + '-' + mm + '-' + dd;
    return formattedDate;
  }

  function moveDays(date, modifier) {
      var new_date = new Date(date);
      new_date.setHours(0,0,0,0);
      if(modifier === 'forward') {
        new_date.setDate(new_date.getDate() + 1);
      }
      else if(modifier === 'back') {
        new_date.setDate(new_date.getDate() - 1);
      }
      return new_date;
  }

  //Datepicker
  $picked_date.pickadate({
    max: today,
    min: earliest_date,
    today: '',
    clear: '',
    close: '',
    format:'mm/dd/yyyy',
    formatSubmit: 'mm/dd/yyyy',
    hiddenName: true
  })

  $cal_trigger.click(function(){
    modal.style.display = 'block';
  })

  $submit_date.click(function() {
    if($picked_date.val() === "")
    {
      $date_error.html('<h4>You need to select a date before jumping!</h4>')
    }
    else {
      modal.style.display = 'none';
      $date_error.html('');
      selected_date = new Date($picked_date.val());
      selected_date.setHours(0,0,0,0);
      //retrieveList('latest');
      var url = "/index/index/bydate/date/" + formatDate(selected_date);
      window.location.href= url;
    }
  })

  //Retrieve list
  function retrieveList(type) {
    var formattedDate = formatDate(selected_date);
    /*
    if(type === 'latest')
    {
      console.log("SUCCESS: ", test);
      populate(test);
      $popular.text('Displaying Latest');
      $popular.removeClass('special');
    }
    else if (type === 'popular')
    {
      var sorted_test = test.slice();
      popularSort(sorted_test);
      console.log("SUCCESS: ", sorted_test);
      populate(sorted_test);
      $popular.text('Displaying Popular');
      $popular.addClass('special');
    }
    */

    $.ajax({
      //Route to get articles by date.
      type: "GET",
      url: '/index/article/readbydate/',
      data: {date: formattedDate},
      success: function (info) {
        if(type === 'latest')
        {
          console.log("SUCCESS: ", info);
          populate(info);
          $popular.text('Displaying Latest');
          $popular.removeClass('special');
        }
        else if (type === 'popular')
        {
          popularSort(info);
          console.log("SUCCESS: ", info);
          populate(info);
          $popular.text('Displaying Popular');
          $popular.addClass('special');
        }
      },
      error: function (e) {
        console.log("ERROR : ", e);
      }
    });

  }

  function popularSort(list) {
    list.sort(function(a, b){
      return b.views - a.views;
    });
  }

  //Populate with list
  function populate(list) {
    console.log(list);
    var $left_col = $('#left_col'),
    $right_col = $('#right_col'),
    $single_col = $('#single_col'),
    $left_arr = $('#left_arr'),
    $right_arr = $('#right_arr'),
    $section_sep = $('#sectionSeparator'),
    left_content = '',
    right_content = '',
    single_content = '',
    left = true;

    $.each(list, function(i, item) {
       var stub =
       '<div id="stubWrapper">' +
          '<div class="box">' +
          /*
            '<div class="iconWrapper hor">' +
              '<i class="fa fa-trash fa"></i>' +
            '</div>' +
          */
            '<a class="stub" data-value="' + list[i].id + '">' +
              '<div class="thumbnailWrapper alt">' +
                '<img src="' + list[i].thumbnail + '"></img>' +
              '</div>' +
              '<p> ' + list[i].punchline + '</p>' +

            '</a>' +
            '<div class="iconWrapper hor">' +
              '<i class="fa fa-facebook-official fa"></i>' +
              '<i class="fa fa-twitter fa"></i>' +
              '<i class="fa fa-thumbs-up fa"></i>' +
            '</div>' +
          '</div>' +
        '</div>';

       if(left) {
         left_content += stub;
         left = false;
       }
       else {
         right_content += stub;
         left = true;
       }

       single_content += stub;
    });

    $left_col.html(left_content);
    $right_col.html(right_content);
    $single_col.html(single_content);

    //Hiding right arrow on today.
    if(selected_date >= today) {
      console.log('Troo');
      $right_arr.addClass('hidden');
      if($left_arr.hasClass('hidden'))
      {
        $left_arr.removeClass('hidden');
      }
    }
    else if(selected_date <= earliest_date){
      console.log('Earliest');
      $left_arr.addClass('hidden');
      if($right_arr.hasClass('hidden'))
      {
        $right_arr.removeClass('hidden');
      }
    }
    else{
       if($right_arr.hasClass('hidden'))
       {
         $right_arr.removeClass('hidden');
       }
       if($left_arr.hasClass('hidden'))
       {
         $left_arr.removeClass('hidden');
       }
    }

    //Changing Header
    var header = "";
    if(formatDate(selected_date) === formatDate(today)) {
       console.log('today');
       header += "<h3>Latest News Today</h3>";
    }
    else{
       console.log('notToday');
       header += "<h3>Latest News on " + formatDate(selected_date) +"</h3>";
    }
    $section_sep.html(header);

  }

  //Left/Right navigation
  $left_arr.click(function () {
    selected_date = moveDays(selected_date, 'back');
    //retrieveList('latest');
    populate(test);

  })

  $right_arr.click(function () {
    selected_date = moveDays(selected_date, 'forward');
    //retrieveList('latest');
    populate(test);

  })
/*
  //Popular Button
  $popular.click(function() {
    if($popular.text() === 'Displaying Latest')
    {
      retrieveList('popular');
    }
    else if($popular.text() === 'Displaying Popular')
    {
      retrieveList('latest');
    }
  })
*/
  $(document).on("click", "a.stub", function() {
    console.log("clicked stub");
    var yattellAID = $(this).data("value");
    window.location.href = "/index/article/read/id/"+yattellAID;
  });

  //End of funcs
  populate(articles);
});
