$(document).ready(function () {

  function validate() {
    var data = localStorage.yattellAccessKey;

    $.ajax({
      type: "POST",
      url: "xxxx",
      data: data,
      success: function(result) {
        console.log('Validated');
      },
      error: function(e) {
        console.log('Access Key Invalid');
        window.location.href="lockscreen.html";
      }
    })
  }

  validate();
});
