$(document).ready(function () {
  var test = {
    id: "123",
    first_name: "John",
    last_name: "Smith",
    middle_name: "Test",
    sex: "M",
    pp: "",
    company: "Yattell",
    job_title: "Madam",
    address: "Nonexistent",
    birthday: "1222-09-01",
    contact_number: "123-456-7890",
    username: "Cyferous",
    create_time: "1222-09-01",
    update_time: "1222-09-01"
  };

  function retrieveUser() {
    var url = '/index/user/profile/key/' + localStorage.yattellAuthKey;
    console.log(localStorage.yattellAuthKey);
    $.ajax({
      type: 'GET',
      url: url,
      success: function (info) {
        console.log('SUCCESS: ', info);
        populate(info);
      },
      error: function(e) {
        console.log('ERROR: ', e);
        window.location.href="login";
      }
    })
  }

  function populate(info) {
    console.log(info);
    let profilePictureWrapper = $('#profilePicture');
    let profileInfoWrapper = $('#profileInfoWrapper');

    if (info.profile_pic === "" | !info.profile_pic) {
      var profilePicture = '<img src="https://st2.depositphotos.com/2101611/8308/v/170/depositphotos_83084388-stock-illustration-businessman-icon-can-be-used.jpg"></img>'
    }
    else {
      var profilePicture = '<img src="' + info.profile_pic + '"></img>';
    }

    var profileInfo =
    '<h2>' + info.nickname + '</h2>' +
    '<p> Name: ' + info.first_name + ' ' + info.last_name + '</p>' +
    '<p> Sex: '+ info.sex + '</p>' +
    '<p> Company: '+ info.company + '</p>' +
    '<p> Job Title: ' + info.job_title + '</p>';

    profilePictureWrapper.append(profilePicture);
    profileInfoWrapper.append(profileInfo);

  /*  <div class="profilePicture" id="profilePicture">
      <img src="./images/crowd.jpg"></img>
    </div>
    <div id="profileInfoWrapper">
      <h2> Username </h2>
      <p> Name: Tony Wang </p>
      <p> Sex: M </p>
    </div> */
  }

  retrieveUser();
});
