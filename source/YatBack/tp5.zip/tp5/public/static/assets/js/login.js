$(document).ready(function() {

  //Modal
  var modal = $('#errorModal')[0];
  var span = $('#close')[0];

  span.onclick = function() {
      modal.style.display = "none";
  }
  window.onclick = function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
      }
  }

  function login() {
    var email = $('#email').val(),
    password = $('#password').val();
    modalBody = $('#modalBody');

    //Data payload
    var data = {
      email: email,
      password: password
    };

    console.log(data);

    $.ajax({
      type: 'POST',
      url: '/index/user/login',
      data: data,
      success: function(info) {
        console.log('SUCCESS: ', info);
        console.log('SUCCESS: ', info.cache_key);
        localStorage.yattellAuthKey = info["cache_key"];
        console.log(localStorage.yattellAuthKey);
        window.location.href = 'profile';
      },
      error: function(e) {
        console.log('ERROR: ', e);
        var error = "<p> An error has occured: " + e.statusText + ".</p>";
        modalBody.html(error);
        modal.style.display = 'block';
      }
    })
  }

  $('#loginButton').click(function () {
    console.log("attempting login");
    login();
  })
});
