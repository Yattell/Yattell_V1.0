<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:92:"/Library/WebServer/Documents/YatBack/tp5/public/../application/index/view/index/article.html";i:1500322346;}*/ ?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Article</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="/static/assets/css/main.css" />
	</head>
  <body class="background2">

    <header id="header" class="altR">

			<!-- Logo -->
			<div class="logo">
				<a href="frontpage.html">
					<img class="inverted" src="/static/assets/css/images/logo1.svg"></img>
				</a>
				<!-- <a href="index.html"><i class="colored icon fa fa-fire"></i> Yattell</a> -->
			</div>

			<!-- Nav -->
			<nav id="nav">
				<ul>
					<li><a href="frontpage.html">Latest</a></li>
					<li><a href="popular.html">Popular</a></li>
					<li><a href="services.html">Services</a></li>
					<li><a href="login.html">Login</a></li>
				</ul>
			</nav>

    </header>

		<section id="navBuffer">
		</section>

		<section id="commentModal" class="modal">
			<!-- Modal content -->
			<div class="modalBodyWrapper" id="modalBodyWrapper">
				<span id="commentClose">&times;</span>
				<div id="modalBody">
					<div id="modalCommentsWrapper">
					</div>

					<div class="repliesWrapper" id="modalRepliesWrapper">
					</div>
				</div>
			</div>

		</section>

		<section id="replyModal" class="modal top">
			<div class="modalBodyWrapper" id="modalBodyWrapper">
				<span id="replyClose">&times;</span>
				<div id="replyModalBody">
					<div class="row">
						<div class="12u">
							<h4> Reply </h4>
							<textarea name="replyField" id="replyField" placeholder="Leave a reply!" rows="6"></textarea>
							<a id="submitReply" class="button fit">Submit Reply</a>
							<div id="replyError">
							</div>
						</div>
					</div>
				</div>
			</div>

		</section>

		<section id="main" class="container alt">
			<div class="row">
				<div class="3u 12u$(medium)" id="furtherReadings">
					<div class="sectionSeparator alt4">
						<h3> Further Readings </h3>
					</div>

				</div>

				<div class="9u$ 12u$(medium) important(medium)">
					<div class="row">
						<div class="12u$">
							<div class="sectionSeparator alt">
								<h3> Summary </h3>
							</div>
							<div class="box alt">

								<div id="summaryWrapper">
									<div class="summaryHeader" id="summaryHeader">
										<h3> This would be where the article's title goes. I hope this is enough room for what I want to do here. </h3>
									</div>

									<hr>

									<div class="summaryContent" id="summaryContent">
										<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
									</div>

									<hr>
									<h4 class="smallHeader"> Related Tags </h4>
									<div class="summaryFooter" id="summaryFooter">
										<div class="tag">
											<p>AI</p>
										</div>
										<div class="tag">
											<p>Fat Albert</p>
										</div>
										<div class="tag">
											<p>Logistics</p>
										</div>
										<div class="tag">
											<p>Capsacian</p>
										</div>
										<div class="tag">
											<p>Asian</p>
										</div>
										<div class="tag">
											<p>Finance</p>
										</div>
										<div class="tag">
											<p>Business</p>
										</div>
										<div class="tag">
											<p>Limited</p>
										</div>
									</div>
								</div>

								<div id="expanderWrapper">
									<a id="tagExpander"><i class="fa fa-angle-double-down fa"></i></a>
								</div>

							</div>
						</div>

						<div class="12u$">
							<div class="sectionSeparator alt2">
								<h3> Full Article </h3>
							</div>
							<div class="box alt">

								<div id="articleWrapper">

									<!-- Content -->
									<div class="contentWrapper" id="articleContent">
										<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
										<img src="http://174.138.59.72:3000/undefined/Grandeur11.jpg"></img>
										<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
										<img src="http://174.138.59.72:3000/undefined/Grandeur11.jpg"></img>
										<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
									</div>

								</div>

								<div id="expanderWrapper">
									<a id="articleExpander"><i class="fa fa-angle-double-down"></i></a>
								</div>

							</div>
						</div>

						<div class="12u$">
							<div class="sectionSeparator alt3">
								<h3> Comments </h3>
							</div>
							<div class="box">
								<div class="row">
									<div class="12u">
										<div id="commentsWrapper">

											<!-- <div class="comment">
												<div class="row 0%">
													<div class="2u 3u(xsmall)">
														<div class="commentBanner">
															<div class="profilePicture">
																<img src="./images/crowd.jpg"></img>
															</div>
															<div class="displayName">
																<p> Cyferous </p>
															</div>
														</div>
													</div>

													<div class="10u$ 9u$(xsmall)">
														<div class="commentContent">
															<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
														</div>
													</div>

													<div class="12u$">
														<div class="commentFooter">
															<div class="row">
																<div class="4u -5u">
																	<div class="actionGroup">
																		<a>
																			<i class="fa fa-comments fa-2x"></i>
																			<p>View Replies</p>
																		</a>
																	</div>
																</div>

																<div class="3u">
																	<div class="actionGroup">
																		<a>
																			<i class="fa fa-mail-reply fa-2x"></i>
																			<p>Reply</p>
																		</a>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div> -->

										</div>
									</div>

									<!-- <div class="12u$">
										<div id="expanderWrapper">
											<a id="moreComments"> Load More Comments </a>
										</div>
									</div> -->

									<div class="12u">
										<hr>
										<h4> Add a comment </h4>
										<textarea name="commentField" id="commentField" placeholder="Leave a comment!" rows="6"></textarea>
										<a id="submitComment" class="button fit">Submit Comment</a>
										<div id="commentError">
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</section>

    <!-- Footer -->
		<footer id="footer">
      <div id="footerWrapper" class="container">
        <ul class="major-icons">
          <li><a href="https://www.facebook.com/yattell/" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
          <li><a href="https://twitter.com/yattell" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
          <li><a href="contact.html" class="icon fa-envelope"><span class="label">Email</span></a></li>
        </ul>
        <p class="copyright">&copy; Yattell Technology Inc. All rights reserved.</p>
      </div>
    </footer>

		<script src="/static/assets/js/jquery.min.js"></script>
		<script src="/static/assets/js/jquery.scrollex.min.js"></script>
		<script src="/static/assets/js/jquery.scrolly.min.js"></script>
		<script src="/static/assets/js/jquery.selectorr.min.js"></script>
		<script src="/static/assets/js/skel.min.js"></script>
		<script src="/static/assets/js/util.js"></script>
		<script src="/static/assets/js/main.js"></script>
		<script src="https://cdn.jsdelivr.net/markdown-it/8.3.1/markdown-it.min.js"></script>
		<script src="/static/assets/js/article.js"></script>

  </body>
</html>
