<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:89:"/Library/WebServer/Documents/YatBack/tp5/public/../application/user/view/user/create.html";i:1497649984;}*/ ?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>创建用户</title>
<style>
body {
  font-family:"Microsoft Yahei","Helvetica Neue",Helvetica,Arial,sans-serif;
  font-size:16px;
  padding:5px;
}
.form{
  padding: 15px;
  font-size: 16px;
}
.form .text {
  padding: 3px;
  margin:2px 10px;
  width: 240px;
  height: 24px;
  line-height: 28px;
  border: 1px solid #D4D4D4;
}
.form.btn{
  margin:6px;
  padding: 6px;
  width: 120px;
  font-size: 16px;
  border: 1px solid #D4D4D4;
  cursor: pointer;
  background:#eee;
}
a{
  color: #868686;
  cursor: pointer;
}
a:hover{
  text-decoration: underline;
}

h2{
  color: #4288ce;
  font-weight: 400;
  padding: 6px 0;
  margin: 6px 0 0;
  font-size: 28px;
  border-bottom: 1px solid #eee;
}
div{
  margin:8px;
}
.info{
  padding: 12px 0;
  border-bottom: 1px solid #eee;
}
.copyright{
  margin-top: 24px;
  padding: 12px 0;
  border-top: 1px solid #eee;
} </style>
</head>
<body>
  <h2>Register</h2>
  <FORM method="post" class="form" action="<?php echo url('user/userinfo/register'); ?>">
    First Name: <INPUT type="text" class="text" name="first_name"><br/>
    Last Name: <INPUT type="text" class="text" name="last_name"><br/>
    Middle Name: <INPUT type="text" class="text" name="middle_name"><br/>
    Sex: <INPUT type="text" class="text" name="sex"><br/>
    Company: <INPUT type="text" class="text" name="company"><br/>
    Job title: <INPUT type="text" class="text" name="job_title"><br/>
    Address: <INPUT type="text" class="text" name="address"><br/>
    Contact Number: <INPUT type="text" class="text" name="contact_number"><br/>
    birthday: <INPUT type="text" class="text" name="birthday"><br/>
    Nickname: <INPUT type="text" class="text" name="nickname"><br/>
    email: <INPUT type="text" class="text" name="email"><br/>
    password: <INPUT type="text" class="text" name="password"><br/>
    Security Question: <INPUT type="text" class="text" name="security_question"><br/>
    Security Answer: <INPUT type="text" class="text" name="security_answer"><br/>
    <input type="hidden" name="__token__" value="<?php echo \think\Request::instance()->token(); ?>" />
    <INPUT type="submit" class="btn" value="Submit">
  </FORM>
<div class="copyright">
<a title="官方网站" href="http://www.thinkphp.cn">ThinkPHP</a>
<span>V5</span>
<span>{ 十年磨一剑-为API开发设计的高性能框架 }</span>
</div>
</body>
</html>
