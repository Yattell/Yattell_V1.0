<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:94:"/Library/WebServer/Documents/YatBack/tp5/public/../application/index/view/article/article.html";i:1500659540;}*/ ?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Article</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />

		<link rel="stylesheet" href="/static/assets/css/main.css" />
		<link rel="stylesheet" href="/static/assets/css/font-awesome.css" />
<!--
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/font-awesome.css" />
-->
	</head>
  <body class="background">

		<header id="header" class="altR">
			<div class="logo">
				<a href="frontpage">
					<img class="inverted" src="/static/assets/css/images/logo1.svg"></img>
				</a>
			</div>

			<nav id="nav">
				<ul>
					<li><a href="frontpage">Latest</a></li>
					<li><a href="frontpage_p">Popular</a></li>
					<li><a href="services">Services</a></li>
					<li id="login_profile"><a href="login">Login</a></li>
				</ul>
			</nav>
		</header>

<!--
    <header id="header" class="altR">

			<div class="logo">
				<a href="frontpage.html">
					<img class="inverted" src="assets/css/images/logo1.svg"></img>
				</a>
			</div>

			<nav id="nav">
				<ul>
					<li><a href="frontpage.html">Latest</a></li>
					<li><a href="frontpage_p.html">Popular</a></li>
					<li><a href="services.html">Services</a></li>
					<li id="login_profile"><a href="login.html">Login</a></li>
				</ul>
			</nav>

    </header>
-->
		<section id="navBuffer">
		</section>

		<section id="commentModal" class="modal">
			<!-- Modal content -->
			<div class="modalBodyWrapper" id="modalBodyWrapper">
				<span id="commentClose">&times;</span>
				<div id="modalBody">
					<div id="modalCommentsWrapper">
					</div>

					<div class="repliesWrapper" id="modalRepliesWrapper">
					</div>
				</div>
			</div>

		</section>

		<section id="replyModal" class="modal top">
			<div class="modalBodyWrapper" id="modalBodyWrapper">
				<span id="replyClose">&times;</span>
				<div id="replyModalBody">
					<div class="row">
						<div class="12u">
							<h4> Reply </h4>
							<textarea name="replyField" id="replyField" placeholder="Leave a reply!" rows="6"></textarea>
							<a id="submitReply" class="button fit">Submit Reply</a>
							<div id="replyError">
							</div>
						</div>
					</div>
				</div>
			</div>

		</section>

		<section id="main" class="container alt">
			<div class="row">
				<div class="3u 12u$(medium)" id="furtherReadings">
					<div class="sectionSeparator alt4">
						<h3> Further Readings </h3>
					</div>
				</div>

				<div class="9u$ 12u$(medium) important(medium)">
					<div class="row">
						<div class="12u$">
							<div class="sectionSeparator alt">
								<h3> Summary </h3>
							</div>
							<div class="box alt">

								<div id="summaryWrapper">
									<div class="summaryHeader" id="summaryHeader">
									</div>

									<hr class="thin">

									<div class="summaryContent" id="summaryContent">
									</div>

									<hr class="thin">
									<h4 class="smallHeader"> Related Tags </h4>
									<div class="summaryFooter" id="summaryFooter">
									</div>

									<div id="expanderWrapper">
										<a id="tagExpander"><i class="fa fa-angle-double-down fa"></i></a>
									</div>
								</div>

							</div>
						</div>

						<div class="12u$">
							<div class="sectionSeparator alt2">
								<h3> Full Article </h3>
							</div>
							<div class="box alt">

								<div id="articleWrapper">

									<!-- Content -->
									<div class="contentWrapper" id="articleContent">
									</div>

								</div>

								<div id="expanderWrapper">
									<a id="articleExpander"><i class="fa fa-angle-double-down"></i></a>
								</div>

							</div>
						</div>

						<div class="12u$">
							<div class="sectionSeparator alt3">
								<h3> Comments </h3>
							</div>
							<div class="box">
								<div class="row">
									<div class="12u">
										<div id="commentsWrapper">

										</div>
									</div>

									<!-- <div class="12u$">
										<div id="expanderWrapper">
											<a id="moreComments"> Load More Comments </a>
										</div>
									</div> -->

									<div class="12u">
										<hr>
										<h4> Add a comment </h4>
										<textarea name="commentField" id="commentField" placeholder="Leave a comment!" rows="6"></textarea>
										<a id="submitComment" class="button fit">Submit Comment</a>
										<div id="commentError">
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</section>

    <!-- Footer -->
		<footer id="footer">
      <div id="footerWrapper" class="container">
        <ul class="major-icons">
          <li><a href="https://www.facebook.com/yattell/" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
          <li><a href="https://twitter.com/yattell" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
<!--
					<li><a href="contact" class="icon fa-envelope"><span class="label">Email</span></a></li>
-->
					<li><a href="contact.html" class="icon fa-envelope"><span class="label">Email</span></a></li>
        </ul>
        <p class="copyright">&copy; Yattell Technology Inc. All rights reserved.</p>
      </div>
    </footer>
		<script>
		 	var test = <?php echo $related; ?>;
			var mycomments = <?php echo $comments; ?>;
			var myarticle = <?php echo $article; ?>;

		</script>
				<script src="/static/assets/js/jquery.min.js"></script>
		    <script src="/static/assets/js/jquery.scrollex.min.js"></script>
		    <script src="/static/assets/js/jquery.scrolly.min.js"></script>
		    <script src="/static/assets/js/jquery.selectorr.min.js"></script>
		    <script src="/static/assets/js/skel.min.js"></script>
		    <script src="/static/assets/js/util.js"></script>
		    <script src="/static/assets/js/main.js"></script>
				<script src="https://cdn.jsdelivr.net/markdown-it/8.3.1/markdown-it.min.js"></script>
				<script src="/static/assets/js/article.js"></script>
		<!--
		<script src="assets/js/jquery.min.js"></script>
		<script src="assets/js/jquery.scrollex.min.js"></script>
		<script src="assets/js/jquery.scrolly.min.js"></script>
		<script src="assets/js/jquery.selectorr.min.js"></script>
		<script src="assets/js/skel.min.js"></script>
		<script src="assets/js/util.js"></script>
		<script src="assets/js/main.js"></script>
		<script src="https://cdn.jsdelivr.net/markdown-it/8.3.1/markdown-it.min.js"></script>
		<script src="assets/js/article.js"></script>
		-->
  </body>
</html>
