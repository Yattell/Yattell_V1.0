<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:90:"/Library/WebServer/Documents/YatBack/tp5/public/../application/index/view/index/index.html";i:1500692565;}*/ ?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Yattell Latest</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="/static/assets/css/main.css" />
		<link rel="stylesheet" href="/static/assets/css/font-awesome.css" />
		<link rel="stylesheet" href="/static/assets/css/default.css" />
		<link rel="stylesheet" href="/static/assets/css/default.date.css" />
		<!--
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/font-awesome.css" />
		<link rel="stylesheet" href="assets/css/default.css" />
		<link rel="stylesheet" href="assets/css/default.date.css" />
	-->
	</head>
	<body class="background">

		<header id="header" class="altR">
			<div class="logo">
				<a href="frontpage">
					<img class="inverted" src="/static/assets/css/images/logo1.svg"></img>
				</a>
			</div>

			<nav id="nav">
				<ul>
					<li><a class="active" href="frontpage">Latest</a></li>
					<li><a href="frontpage_p">Popular</a></li>
					<li><a href="services">Services</a></li>
					<li id="login_profile"><a href="login">Login</a></li>
				</ul>
			</nav>
		</header>


		<section id="navBuffer">
		</section>

		<section id="datePickerModal" class="modal">
			<!-- Modal content -->
			<div class="modalBodyWrapper" id="modalBodyWrapper">
				<span id="close">&times;</span>
				<div class="modalBody" id="modalBody">
					<div class"row">
						<h3> Jump to date: </h3>
						<div class="12u">
							<input type="text" id="picked_date"></input>
							<div id="date_error">
							</div>
						</div>
						<div class="12u">
							<ul class="actions fit">
								<li><a id="submit_date" class="button fit">Jump</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>

		</section>

		<section id="main" class="container alt restricted">
			<div class = "row">
				<!-- L-Sidebar -->
				<div class="1u">
					<div class="selectorWrapper"  id="left_arr">
						<a>
							<i class="fa fa-angle-left fa-4x"> </i>
						</a>
					</div>
				</div>

				<!-- Center-Column -->
				<div class="10u -1u">

					<!-- Header -->
					<div class="row">
						<div class="11u">
							<div class="sectionSeparator alt2" id="sectionSeparator">
								<h3> Latest News Today </h3>
							</div>
						</div>
						<div class="1u$">
							<div class="calendarPicker">
								<a id="cal_trigger"><i class="fa fa-calendar-o fa-2x" ></i></a>
							</div>
						</div>
						<!--
						<div class="12u" style="text-align: right">
							<a id="popular" class="button">Displaying Latest</a>
						</div>
					-->
					</div>

					<!-- Content -->
					<div class="row 50%">
						<div class="6u 12u$(medium) hiddenMedium" id="left_col">
						</div>

						<div class="6u$ 12u$(medium) hiddenMedium" id="right_col">
						</div>

						<div class="12u$ revealMedium" id="single_col">
						</div>

					</div>

				</div>

				<!-- R-Sidebar -->
				<div class="1u">
					<div class="selectorWrapper right" id="right_arr">
						<a>
							<i class="fa fa-angle-right fa-4x"> </i>
						</a>
					</div>
				</div>
			</div>
		</section>

    <!-- Footer -->
		<footer id="footer">
      <div id="footerWrapper" class="container">
        <ul class="major-icons">
          <li><a href="https://www.facebook.com/yattell/" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
          <li><a href="https://twitter.com/yattell" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
<!--
					<li><a href="contact" class="icon fa-envelope"><span class="label">Email</span></a></li>
-->
					<li><a href="contact.html" class="icon fa-envelope"><span class="label">Email</span></a></li>
        </ul>
        <p class="copyright">&copy; Yattell Technology Inc. All rights reserved.</p>
      </div>
    </footer>
		<script>
		 	var myarticles = <?php echo $list; ?>;
			var recievedDate = <?php echo $date; ?>;
		</script>

		<script src="/static/assets/js/jquery.min.js"></script>
    <script src="/static/assets/js/jquery.scrollex.min.js"></script>
    <script src="/static/assets/js/jquery.scrolly.min.js"></script>
    <script src="/static/assets/js/jquery.selectorr.min.js"></script>
    <script src="/static/assets/js/skel.min.js"></script>
    <script src="/static/assets/js/util.js"></script>
		<script src="/static/assets/js/frontpage.js"></script>
		<script src="/static/assets/js/picker.js"></script>
		<script src="/static/assets/js/picker.date.js"></script>
    <script src="/static/assets/js/main.js"></script>

		<!-- <script src="assets/js/loggedin.js"></script> -->


  </body>
</html>
