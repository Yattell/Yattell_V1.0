<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:90:"/Library/WebServer/Documents/YatBack/tp5/public/../application/index/view/index/login.html";i:1500325717;}*/ ?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Login</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="/static/assets/css/main.css" />
	</head>
	<body class="background">

    <header id="header" class="altR">

			<!-- Logo -->
			<div class="logo">
				<a href="frontpage.html">
					<img class="inverted" src="/static/assets/css/images/logo1.svg"></img>
				</a>
				<!-- <a href="index.html"><i class="colored icon fa fa-fire"></i> Yattell</a> -->
			</div>

			<!-- Nav -->
			<nav id="nav">
				<ul>
					<li><a href="frontpage.html">Latest</a></li>
					<li><a href="services.html">Services</a></li>
					<li><a class="active" href="login.html">Login</a></li>
				</ul>
			</nav>

    </header>

		<section id="navBuffer">
		</section>

		<section id="errorModal" class="modal">
			<!-- Modal content -->
			<div class="modalBodyWrapper" id="modalBodyWrapper">
				<span id="close">&times;</span>
				<div class="modalBody" id="modalBody">
				</div>
			</div>

		</section>

		<section id="main" class="container alt">
			<div class="row">
				<div class="8u -2u">
					<div class="sectionSeparator alt">
						<h3> Login </h3>
					</div>
					<div class="box">
						<form method="post" action="#">
							<h3> Email </h3>
							<input type="text" name="email" id="email" value="" placeholder="Email" class="gap"/>
							<h3> Password </h3>
							<input type="password" name="password" id="password" value="" placeholder="Password"/>
							<hr>
							<ul class="actions fit">
								<li><a href="passwordrecovery.html" class="button alt fit">Forgot Password</a></li>
								<li><a id="loginButton" class="button fit">Login</a></li>
							</ul>
						</form>
					</div>

					<hr class="major">
					<div class="sectionSeparator alt4">
						<h3> Need to Register? </h3>
					</div>
				</div>
			</div>
		</section>

		<section id="splitWrapper">
				<div class="firstHalf">
					<h3> Regular </h3>
					<div class="row">
						<div class="8u -2u">
							<ul>
								<li>Track your browsing history on your profile page.</li>
								<li>Like and share articles with friends and social networks.</li>
								<li>Favourite articles for later viewing.</li>
								<li>Comment and participate in battlefield discussions and annotations.</li>
								<li>Access our services team.</li>
								<li>More perks comming soon...!</li>
							</ul>
					</div>
				</div>
				<div class="buttonWrapper">
						<hr>
						<a href="register.html" class="button special fit">Register</a>
				</div>
			</div>

				<div class="secondHalf">
					<h3> VIP </h3>
					<div class="row">
						<div class="8u -2u">
							<ul>
								<li>Customize and personalize your profile page.</li>
								<li>Access more features in the comment,battlefield and annotation systems.</li>
								<li>Cheaper advertising for your own ventures/companies as well as fixed monthly exposure opportunities.</li>
								<li>Priority access to our services team.</li>
								<li>Exclusive communications channel to our executive and development teams.</li>
								<li>Improved chances of becomming a certified professional user.</li>
								<li>More perks comming soon...!</li>
							</ul>
						</div>
					</div>
					<div class="buttonWrapper">
							<hr>
							<a class="button special fit disabled">Coming Soon!</a>
					</div>
				</div>
		</section>

    <!-- Footer -->
		<footer id="footer">
      <div id="footerWrapper" class="container">
        <ul class="major-icons">
          <li><a href="https://www.facebook.com/yattell/" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
          <li><a href="https://twitter.com/yattell" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
          <li><a href="contact.html" class="icon fa-envelope"><span class="label">Email</span></a></li>
        </ul>
        <p class="copyright">&copy; Yattell Technology Inc. All rights reserved.</p>
      </div>
    </footer>

		<script src="/static/assets/js/jquery.min.js"></script>
    <script src="/static/assets/js/jquery.scrollex.min.js"></script>
    <script src="/static/assets/js/jquery.scrolly.min.js"></script>
    <script src="/static/assets/js/jquery.selectorr.min.js"></script>
    <script src="/static/assets/js/skel.min.js"></script>
    <script src="/static/assets/js/util.js"></script>
    <script src="/static/assets/js/main.js"></script>
		<script src="/static/assets/js/login.js"></script>
		<!-- <script src='/static/assets/js/validate.js'></script> -->

  </body>
</html>
