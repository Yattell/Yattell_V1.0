<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:91:"/Library/WebServer/Documents/YatBack/tp5/public/../application/index/view/index/upload.html";i:1500710132;}*/ ?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Upload</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
]
			<link rel="stylesheet" href="/static/assets/css/main.css" />
			<link rel="stylesheet" href="/static/assets/css/font-awesome.css" />
			<link rel="stylesheet" href="/static/assets/css/simplemde.min.css" />
		<!--
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/font-awesome.css" />
		<link rel="stylesheet" href="assets/css/simplemde.min.css" />
	-->
	</head>
  <body class="background">

		<header id="header" class="altR">
			<div class="logo">
				<a href="frontpage">
					<img class="inverted" src="/static/assets/css/images/logo1.svg"></img>
				</a>
			</div>

			<nav id="nav">
				<ul>
					<li><a href="frontpage">Latest</a></li>
					<li><a href="frontpage_p">Popular</a></li>
					<li><a href="services">Services</a></li>
					<li id="login_profile"><a href="login">Login</a></li>
				</ul>
			</nav>
		</header>


		<section id="navBuffer">
		</section>

		<section id="main" class="container">
			<div class="row">
				<div class="12u">
					<div class="sectionSeparator alt2">
						<h3> Article Upload </h3>
					</div>

					<div class="box">
						<form method="post" action="#">
							<div class="row uniform 50%">

								<!-- Title -->
								<div class="12u$">
									<h3> Article Title </h3>
									<input type="text" name="title" id="title" value="" placeholder="Article Title" />
								</div>

								<!-- Tags -->
								<div class="12u">
									<h3> Loose Tags </h3>
									<textarea name="looseTags" id="looseTags" placeholder="Loose Tags go here, please separate by commas. Ex: ai,finance,business" rows="6"></textarea>
								</div>

								<div class="12u">
									<h3> Strong Tags </h3>
									<textarea name="specificTags" id="specificTags" placeholder="Specific Tags go here, please separate by commas. Ex: ai,finance,business. These tags will be publically displayed." rows="6"></textarea>
								</div>

								<!-- Punchline -->
								<div class="12u">
									<h3> Article Punchline </h3>
									<textarea name="punchline" id="punchline" placeholder="Punchline goes here." rows="3"></textarea>
								</div>

								<!-- Article Summary -->
								<div class="12u">
									<h3> Article Summary </h3>
									<textarea name="summary" id="summary" placeholder="Summary goes here." rows="12"></textarea>
								</div>

								<!-- Article Body -->
								<div class="12u">
									<h3> Article Body </h3>
									<textarea name="article" id="article" placeholder="Article Source goes here." rows="64"></textarea>
								</div>

								<!-- Thumbnail -->
								<div class="12u">
									<h3> Thumbnail </h3>
									<input type="text" name="thumbnail" id="thumbnail" placeholder="URL to a thumbnail image. Please use the image uploader below to upload a new image and obtain a link."></input>
									<label for="thumbnail">Thumbnail Image Link</label>
									<a id="btnSubmitArticle" class="button">Upload Article</a>
									<div id="errorMessage">
									</div>
								</div>

							</div>
						</form>
					</div>

					<div class="sectionSeparator alt2">
						<h3>Image Upload</h3>
					</div>
					<div class="box">
						<div class="row">
							<div class="6u$">
								<form id="imageUpload" method="POST" enctype="multipart/form-data">
									<input type="file" name="myimage" ></input>
									<input type="submit" id="btnSubmitImg" class="button" value="Upload Image"></input>
								</form>
							</div>
							<div class="12u$">
								<div id="linkDisplay">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!-- Footer -->
		<footer id="footer">
      <div id="footerWrapper" class="container">
        <ul class="major-icons">
          <li><a href="https://www.facebook.com/yattell/" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
          <li><a href="https://twitter.com/yattell" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
<!--
					<li><a href="contact" class="icon fa-envelope"><span class="label">Email</span></a></li>
-->
					<li><a href="contact.html" class="icon fa-envelope"><span class="label">Email</span></a></li>
        </ul>
        <p class="copyright">&copy; Yattell Technology Inc. All rights reserved.</p>
      </div>
    </footer>

			<script src="/static/assets/js/jquery.min.js"></script>
	    <script src="/static/assets/js/jquery.scrollex.min.js"></script>
	    <script src="/static/assets/js/jquery.scrolly.min.js"></script>
	    <script src="/static/assets/js/jquery.selectorr.min.js"></script>
	    <script src="/static/assets/js/skel.min.js"></script>
	    <script src="/static/assets/js/util.js"></script>
	    <script src="/static/assets/js/main.js"></script>
			<script src="/static/assets/js/simplemde.min.js"></script>
			<script src="/static/assets/js/upload.js"></script>
<!--
		<script src="assets/js/jquery.min.js"></script>
		<script src="assets/js/jquery.scrollex.min.js"></script>
		<script src="assets/js/jquery.scrolly.min.js"></script>
		<script src="assets/js/jquery.selectorr.min.js"></script>
		<script src="assets/js/skel.min.js"></script>
		<script src="assets/js/util.js"></script>
		<script src="assets/js/main.js"></script>
		<script src="assets/js/simplemde.min.js"></script>
		<script src="assets/js/upload.js"></script>
-->
  </body>
</html>
