<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:94:"/Library/WebServer/Documents/YatBack/tp5/public/../application/index/view/article/display.html";i:1498255078;}*/ ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>查看文章</title>
<style>
body{
  color: #333;
  font: 16px Verdana, "Helvetica Neue", helvetica, Arial, 'Microsoft YaHei', sans-serif;
  margin: 0px;
  padding: 20px;
}

a{
  color: #868686;
  cursor: pointer;
}

a:hover{
   text-decoration: underline;
}

h2{
  color: #4288ce;
  font-weight: 400;
  padding: 6px 0;
  margin: 6px 0 0;
  font-size: 28px;
  border-bottom: 1px solid #eee;
}
div{
  margin:8px;
}
.info{
  padding: 12px 0;
  border-bottom: 1px solid #eee;
}
.copyright{
  margin-top: 24px;
  padding: 12px 0;
  border-top: 1px solid #eee;
}
</style>
</head>
<body>
<h2>查看文章<?php echo $count; ?>）</h2>
<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$article): $mod = ($i % 2 );++$i;?>
<div class="info">
article id：<?php echo $article['id']; ?><br/>
title：<?php echo $article['title']; ?><br/>
summary：<?php echo $article['summary']; ?><br/>
content: <?php echo $article['content']; ?><br/>
views：<?php echo $article['views']; ?><br/>
create time:<?php echo $article['create_time']; ?><br/>
update time:<?php echo $article['update_time']; ?><br/>
</div>
<?php endforeach; endif; else: echo "" ;endif; ?>
<div class="copyright">
  <a title="官方网站" href="http://www.thinkphp.cn">ThinkPHP</a>
  <span>V5</span>
  <span>{ 十年磨一剑-为API开发设计的高性能框架 }</span>
</div>
</body>
</html>
