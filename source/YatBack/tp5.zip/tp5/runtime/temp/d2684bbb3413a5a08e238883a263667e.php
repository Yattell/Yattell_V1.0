<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:92:"/Library/WebServer/Documents/YatBack/tp5/public/../application/index/view/index/profile.html";i:1500321682;}*/ ?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Profile</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="/static/assets/css/main.css" />
	</head>
  <body class="background">

    <header id="header" class="altR">

			<!-- Logo -->
			<div class="logo">
				<a href="frontpage.html">
					<img class="inverted" src="/static/assets/css/images/logo1.svg"></img>
				</a>
				<!-- <a href="index.html"><i class="colored icon fa fa-fire"></i> Yattell</a> -->
			</div>

			<!-- Nav -->
			<nav id="nav">
				<ul>
					<li><a href="frontpage.html">Latest</a></li>
					<li><a href="services.html">Services</a></li>
					<li><a href="login.html">Login</a></li>
				</ul>
			</nav>

    </header>

		<section id="navBuffer">
		</section>

		<section id="main" class="container">
      <div class="sectionSeparator alt4">
        <h3> Profile </h3>
      </div>
      <div class="row">
        <div class="12u$">
          <div class="box">
            <div class="row">
              <div class="4u 3u(medium) 12u$(small)">
                <div class="profilePicture" id="profilePicture">
                </div>

                <div id="profileInfoWrapper">
                </div>


              </div>

              <div class="8u 9u(medium) 12u$(small)">
                <h3> Browsing History </h3>
                <hr>

              </div>

            </div>
          </div>
        </div>
      </div>
		</section>

    <!-- Footer -->
		<footer id="footer">
      <div id="footerWrapper" class="container">
        <ul class="major-icons">
          <li><a href="https://www.facebook.com/yattell/" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
          <li><a href="https://twitter.com/yattell" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
          <li><a href="contact.html" class="icon fa-envelope"><span class="label">Email</span></a></li>
        </ul>
        <p class="copyright">&copy; Yattell Technology Inc. All rights reserved.</p>
      </div>
    </footer>

		<script src="/static/assets/js/jquery.min.js"></script>
		<script src="/static/assets/js/jquery.scrollex.min.js"></script>
		<script src="/static/assets/js/jquery.scrolly.min.js"></script>
		<script src="/static/assets/js/jquery.selectorr.min.js"></script>
		<script src="/static/assets/js/skel.min.js"></script>
		<script src="/static/assets/js/util.js"></script>
		<script src="/static/assets/js/main.js"></script>
		<script src="/static/assets/js/profile.js"></script>


  </body>
</html>
