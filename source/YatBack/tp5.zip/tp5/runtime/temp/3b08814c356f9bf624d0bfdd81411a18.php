<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:93:"/Library/WebServer/Documents/YatBack/tp5/public/../application/index/view/index/register.html";i:1500321684;}*/ ?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Register</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="/static/assets/css/main.css" />
	</head>
	<body class="background">

    <header id="header" class="altR">

			<!-- Logo -->
			<div class="logo">
				<a href="frontpage.html">
					<img class="inverted" src="/static/assets/css/images/logo1.svg"></img>
				</a>
				<!-- <a href="index.html"><i class="colored icon fa fa-fire"></i> Yattell</a> -->
			</div>

			<!-- Nav -->
			<nav id="nav">
				<ul>
					<li><a href="frontpage.html">Latest</a></li>
					<li><a href="services.html">Services</a></li>
					<li><a class="active" href="login.html">Login</a></li>
				</ul>
			</nav>

    </header>

		<section id="navBuffer">
		</section>

		<section id="errorModal" class="modal">
		  <!-- Modal content -->
		  <div class="modalBodyWrapper" id="modalBodyWrapper">
		    <span id="close">&times;</span>
				<div class="modalBody" id="modalBody">
				</div>
		  </div>

		</section>

		<section id="main" class="container">
			<div class="row">
				<!-- Registration Form -->
				<div class="10u -1u 12u$(medium)">
					<div class="sectionSeparator alt3">
						<h3> User Registration </h3>
					</div>
					<div class="box">
						<form method="post" action="#">
							<div class="row">
								<!-- Required -->
								<div class="6u 12u$(small)">
									<h2 class="light"> Required </h2>
									<hr>
									<h3> Username *</h3>
									<input type="text" name="username" id="username" value="" placeholder="Username" class="gap"/>
									<h3> Email *</h3>
									<input type="email" name="email" id="email" value="" placeholder="Email" class="gap"/>
									<h3> Password *</h3>
									<input type="password" name="password" id="password" value="" placeholder="Password" class="gap"/>
									<h3> Retype Password *</h3>
									<input type="password" name="re_password" id="re_password" value="" placeholder="Retype Password" class="gap"/>
									<h3> First Name *</h3>
									<input type="text" name="first_name" id="first_name" value="" placeholder="First Name" class="gap"/>
									<h3> Last Name *</h3>
									<input type="text" name="last_name" id="last_name" value="" placeholder="Last Name" class="gap"/>
								</div>

								<!-- Optional -->
								<div class="6u 12u$(small)">
									<h2 class="light"> Optional </h2>
									<hr>
									<h3> Sex </h3>
									<div class="row">
										<div class="4u 12u$(small)">
											<input type="radio" id="sex-male" name="sex" value="Male">
											<label for="sex-male">Male</label>
										</div>
										<div class="4u 12u$(small)">
											<input type="radio" id="sex-female" name="sex" value="Female">
											<label for="sex-female">Female</label>
										</div>
										<div class="4u$ 12u$(small)">
											<input type="radio" id="sex-other" name="sex" value="Other">
											<label for="sex-other">Other</label>
										</div>
									</div>
									<h3> Profile Picture </h3>
									<input type="text" name="profile_picture" id="profile_picture" value="" placeholder="Link to Profile Picture (128px X 128px)" class="gap"/>
									<h3> Company </h3>
									<input type="text" name="company" id="company" value="" placeholder="Company" class="gap"/>
									<h3> Job Title </h3>
									<input type="text" name="job_title" id="job_title" value="" placeholder="Job Title" class="gap"/>
									<h3> Contact Number </h3>
									<input type="text" name="contact_number" id="contact_number" value="" placeholder="Contact Number" class="gap"/>

									<input type="checkbox" id="startup" name="startup">
									<label for="startup">Are you part of a technology start-up?</label>
									<input type="checkbox" id="executive" name="executive">
									<label for="executive">Are you a part of a core/executive team in your company?</label>
								</div>
								<div class="12u$">
									<hr>
									<h3> Security * </h3>
									<div class="select-wrapper">
										<select name="security_question" id="security_question">
											<option value="What was the name of your first pet?">What was the name of your first pet?</option>
											<option value="When was your grandmother born?">When was your grandmother born?</option>
											<option value="What is the most memorable street you have lived on?">What is the most memorable street you have lived on?</option>
											<option value="What is you favourite movie?">What is you favourite movie?</option>
										</select>
									</div>
									<input type="text" name="security_answer" id="security_answer" value="" placeholder="Security Question Answer" class="gap"/>

									<input type="checkbox" id="terms" name="terms">
									<label for="terms">Do you agree to our <a href="https://www.dropbox.com/s/4qa8nifw6253xgz/Yattell%20Terms%20and%20Conditions.docx?dl=0">terms of service agreement?</a> </label>

								</div>
							</div>
							<hr>
							<ul class="actions fit">
								<li><a href="register.html" id="resetButton" type="reset" class="button alt fit">Reset Fields</a></li>
								<li><a id="registerButton" class="button fit">Register</a></li>
							</ul>
						</form>
					</div>
				</div>
			</div>
		</section>

    <!-- Footer -->
		<footer id="footer">
      <div id="footerWrapper" class="container">
        <ul class="major-icons">
          <li><a href="https://www.facebook.com/yattell/" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
          <li><a href="https://twitter.com/yattell" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
          <li><a href="contact.html" class="icon fa-envelope"><span class="label">Email</span></a></li>
        </ul>
        <p class="copyright">&copy; Yattell Technology Inc. All rights reserved.</p>
      </div>
    </footer>

		<script src="/static/assets/js/jquery.min.js"></script>
		<script src="/static/assets/js/jquery.scrollex.min.js"></script>
		<script src="/static/assets/js/jquery.scrolly.min.js"></script>
		<script src="/static/assets/js/jquery.selectorr.min.js"></script>
		<script src="/static/assets/js/skel.min.js"></script>
		<script src="/static/assets/js/util.js"></script>
		<script src="/static/assets/js/main.js"></script>
		<script src="/static/assets/js/register.js"></script>


  </body>
</html>
