<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:95:"/Library/WebServer/Documents/YatBack/tp5/public/../application/index/view/index/lockscreen.html";i:1500717104;}*/ ?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Lockscreen</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />

			<link rel="stylesheet" href="/static/assets/css/main.css" />
			<link rel="stylesheet" href="/static/assets/css/font-awesome.css" />
<!--
			<link rel="stylesheet" href="assets/css/main.css" />
			<link rel="stylesheet" href="assets/css/font-awesome.css" />
-->
	</head>
  <body class="background">

    <section id="lockScreen" class="modal lockscreen">
			<!-- Modal content -->
			<div class="modalBodyWrapper" id="modalBodyWrapper">
				<div class="modalBody" id="modalBody">
					<div class="row">
						<div class="12u$">
							<div class="imgContainer">
								<img src="assets/css/images/logo1.svg"></img>
							</div>
						</div>
						<div class="6u$ -3u 12u$(small)">
							<h3 style="text-align: center"><strong> Enter Access Key </strong></h3>
							<input type="text" id="accessKey" placeholder="Access Key"></input>
							<input type="submit" id="btnSubmitKey" class="button fit" value="Submit Key"></input>
							<div id="keyError">
							</div>
						</div>
					</div>
				</div>
			</div>

		</section>

		<script src="/static/assets/js/jquery.min.js"></script>
    <script src="/static/assets/js/jquery.scrollex.min.js"></script>
    <script src="/static/assets/js/jquery.scrolly.min.js"></script>
    <script src="/static/assets/js/jquery.selectorr.min.js"></script>
    <script src="/static/assets/js/skel.min.js"></script>
    <script src="/static/assets/js/util.js"></script>
    <script src="/static/assets/js/lockscreen.js"></script>
<!--
		<script src="assets/js/jquery.min.js"></script>
		<script src="assets/js/jquery.scrollex.min.js"></script>
		<script src="assets/js/jquery.scrolly.min.js"></script>
		<script src="assets/js/jquery.selectorr.min.js"></script>
		<script src="assets/js/skel.min.js"></script>
		<script src="assets/js/util.js"></script>
		<script src="assets/js/lockscreen.js"></script>
-->
  </body>
</html>
